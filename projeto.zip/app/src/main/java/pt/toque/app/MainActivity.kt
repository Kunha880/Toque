package pt.toque.app

import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.nfc.NfcAdapter
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Guarda só um hash do PIN (PBKDF2 + sal aleatório), nunca o PIN. */
class PinStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("lock", Context.MODE_PRIVATE)

    fun hasPin(): Boolean = p.contains("hash")

    fun setPin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        p.edit()
            .putString("salt", toHex(salt))
            .putString("hash", toHex(derive(pin, salt)))
            .putInt("fails", 0)
            .putLong("until", 0L)
            .apply()
    }

    fun secondsLocked(): Long {
        val left = p.getLong("until", 0L) - System.currentTimeMillis()
        return if (left > 0) (left + 999) / 1000 else 0L
    }

    fun check(pin: String): Boolean {
        val salt = fromHex(p.getString("salt", "") ?: "")
        val expected = fromHex(p.getString("hash", "") ?: "")
        val ok = MessageDigest.isEqual(derive(pin, salt), expected)
        if (ok) {
            p.edit().putInt("fails", 0).putLong("until", 0L).apply()
        } else {
            val fails = p.getInt("fails", 0) + 1
            val e = p.edit().putInt("fails", fails)
            if (fails >= 5) {
                val wait = 30_000L * (1L shl minOf(fails - 5, 6))
                e.putLong("until", System.currentTimeMillis() + wait)
            }
            e.apply()
        }
        return ok
    }

    private fun derive(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 150_000, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    private fun toHex(b: ByteArray): String = b.joinToString("") { "%02x".format(it) }

    private fun fromHex(s: String): ByteArray =
        s.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
}

class MainActivity : Activity() {

    private lateinit var store: PinStore
    private var unlocked = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Bloqueia capturas de ecrã e esconde o conteúdo na lista de apps recentes
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )
        store = PinStore(this)
    }

    override fun onStart() {
        super.onStart()
        render()
    }

    // Sempre que a app vai para segundo plano, volta a bloquear
    override fun onStop() {
        super.onStop()
        unlocked = false
    }

    private fun render() {
        when {
            !store.hasPin() -> showSetPin(null)
            !unlocked -> showUnlock(null)
            else -> showHome()
        }
    }

    // ---------- Ecrãs ----------

    private fun showSetPin(first: String?) {
        val field = pinField()
        val msg = body("")
        val btn = Button(this).apply {
            text = if (first == null) "Continuar" else "Confirmar PIN"
            setOnClickListener {
                val v = field.text.toString()
                if (first == null) {
                    if (v.length < 6) {
                        msg.text = "O PIN precisa de pelo menos 6 números."
                    } else {
                        showSetPin(v)
                    }
                } else {
                    if (v == first) {
                        store.setPin(v)
                        unlocked = true
                        render()
                    } else {
                        msg.text = "Os PINs não coincidem. Começa de novo."
                        showSetPin(null)
                    }
                }
            }
        }
        screen(
            title("Toque"),
            body(if (first == null) "Cria um PIN para a app (mínimo 6 números)." else "Repete o PIN."),
            field, msg, btn
        )
    }

    private fun showUnlock(error: String?) {
        val field = pinField()
        val msg = body(error ?: "")
        val btn = Button(this).apply {
            text = "Desbloquear"
            setOnClickListener {
                val wait = store.secondsLocked()
                if (wait > 0) {
                    msg.text = "Demasiadas tentativas. Espera $wait s."
                } else if (store.check(field.text.toString())) {
                    unlocked = true
                    render()
                } else {
                    val w = store.secondsLocked()
                    showUnlock(if (w > 0) "PIN errado. Espera $w s." else "PIN errado.")
                }
            }
        }
        screen(title("Toque"), body("Introduz o PIN."), field, msg, btn)
    }

    private fun showHome() {
        val nfc = NfcAdapter.getDefaultAdapter(this)
        val nfcTxt = when {
            nfc == null -> "NFC: este telemóvel não tem."
            !nfc.isEnabled -> "NFC: desligado (liga-o nas definições)."
            else -> "NFC: ligado."
        }
        val hce = packageManager.hasSystemFeature(PackageManager.FEATURE_NFC_HOST_CARD_EMULATION)
        val hceTxt = if (hce) "Emulação de cartão (HCE): sim." else "Emulação de cartão (HCE): NÃO. O emparelhamento por toque pode não funcionar."

        val lock = Button(this).apply {
            text = "Bloquear agora"
            setOnClickListener { unlocked = false; render() }
        }
        val change = Button(this).apply {
            text = "Alterar PIN"
            setOnClickListener { showSetPin(null) }
        }
        screen(
            title("Toque"),
            body("Ainda não tens contactos.\n\nFase 1 (v0.1): bloqueio por PIN, sem capturas de ecrã, sem cópias de segurança. O emparelhamento por toque vem na fase 2."),
            body("$nfcTxt\n$hceTxt"),
            lock, change
        )
    }

    // ---------- Ajudas de interface ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun screen(vararg views: View) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(64), dp(24), dp(24))
        }
        views.forEach { box.addView(it) }
        setContentView(ScrollView(this).apply { addView(box) })
    }

    private fun title(t: String) = TextView(this).apply {
        text = t
        textSize = 28f
        gravity = Gravity.CENTER
    }

    private fun body(t: String) = TextView(this).apply {
        text = t
        textSize = 16f
        setPadding(0, dp(16), 0, dp(16))
    }

    private fun pinField() = EditText(this).apply {
        hint = "PIN"
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
    }
}
