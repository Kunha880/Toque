plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "pt.toque.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "pt.toque.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "2.0-nfc-prototype"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
