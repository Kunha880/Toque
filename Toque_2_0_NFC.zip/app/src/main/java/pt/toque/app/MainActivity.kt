package pt.toque.app

import android.app.Activity
import android.content.Context
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.IsoDep
import android.os.Bundle
import android.view.WindowManager
import android.widget.*
import android.graphics.Typeface
import android.content.pm.PackageManager
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

class PinStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("lock", Context.MODE_PRIVATE)
    fun hasPin() = p.contains("hash")
    fun setPin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        p.edit().putString("salt", salt.hex()).putString("hash", derive(pin, salt).hex())
            .putInt("fails", 0).putLong("until", 0L).apply()
    }
    fun secondsLocked(): Long = ((p.getLong("until", 0L) - System.currentTimeMillis()).coerceAtLeast(0) + 999) / 1000
    fun check(pin: String): Boolean {
        val salt = p.getString("salt", "")!!.unhex()
        val expected = p.getString("hash", "")!!.unhex()
        val ok = MessageDigest.isEqual(derive(pin, salt), expected)
        if (ok) p.edit().putInt("fails", 0).putLong("until", 0L).apply()
        else {
            val fails = p.getInt("fails", 0) + 1
            val edit = p.edit().putInt("fails", fails)
            if (fails >= 5) edit.putLong("until", System.currentTimeMillis() + 30_000L * (1L shl (fails - 5).coerceAtMost(6)))
            edit.apply()
        }
        return ok
    }
    private fun derive(pin: String, salt: ByteArray): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(pin.toCharArray(), salt, 150_000, 256)).encoded
    private fun ByteArray.hex() = joinToString("") { "%02x".format(it) }
    private fun String.unhex() = chunked(2).map { it.toInt(16).toByte() }.toByteArray()
}

class MainActivity : Activity() {
    private lateinit var pinStore: PinStore
    private var unlocked = false
    private var nfc: NfcAdapter? = null
    private var readerEnabled = false
    private var statusView: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        pinStore = PinStore(this)
        nfc = NfcAdapter.getDefaultAdapter(this)
    }

    override fun onStart() { super.onStart(); render() }
    override fun onStop() {
        disableReader()
        unlocked = false
        super.onStop()
    }

    private fun render() {
        when {
            !pinStore.hasPin() -> pinScreen(null)
            !unlocked -> pinScreen("")
            else -> home()
        }
    }

    private fun pinScreen(first: String?) {
        val field = EditText(this).apply {
            hint = "PIN (mínimo 6 números)"
            inputType = 0x00000012
        }
        val message = label("")
        val button = Button(this).apply {
            text = if (first == null) "Criar PIN" else if (first.isEmpty()) "Desbloquear" else "Confirmar PIN"
            setOnClickListener {
                val value = field.text.toString()
                when {
                    first == null && value.length >= 6 -> pinScreen(value)
                    first == null -> message.text = "O PIN precisa de pelo menos 6 números."
                    first.isEmpty() -> {
                        val wait = pinStore.secondsLocked()
                        if (wait > 0) message.text = "Bloqueado. Espera $wait segundos."
                        else if (pinStore.check(value)) { unlocked = true; render() }
                        else { message.text = "PIN incorreto." }
                    }
                    first == value -> { pinStore.setPin(value); unlocked = true; render() }
                    else -> pinScreen(null)
                }
            }
        }
        show(label("TOQUE", 28f, true), label(if (first == null) "Cria um PIN para proteger a aplicação." else if (first.isEmpty()) "Introduz o teu PIN." else "Repete o PIN."), field, message, button)
    }

    private fun home() {
        val adapter = nfc
        val supportsNfc = adapter != null
        val supportsHce = packageManager.hasSystemFeature(PackageManager.FEATURE_NFC_HOST_CARD_EMULATION)
        val status = label(
            "NFC: " + when {
                !supportsNfc -> "não disponível"
                !adapter!!.isEnabled -> "desligado — ativa-o nas definições"
                else -> "ligado"
            } + "\nHCE: " + if (supportsHce) "disponível" else "não disponível neste equipamento"
        )
        statusView = label("Escolhe uma operação.")
        val share = Button(this).apply {
            text = "Apresentar o meu contacto por NFC"
            setOnClickListener {
                if (adapter == null || !adapter.isEnabled || !supportsHce) {
                    statusView?.text = "Este equipamento precisa de NFC ligado e suporte HCE."
                } else {
                    disableReader()
                    statusView?.text = "Pronto para partilhar. Mantém este ecrã aberto e aproxima o outro telemóvel em modo «Ler contacto»."
                }
            }
        }
        val read = Button(this).apply {
            text = "Ler contacto por NFC"
            setOnClickListener {
                if (adapter == null || !adapter.isEnabled) {
                    statusView?.text = "Ativa o NFC nas definições do Android."
                } else {
                    enableReader()
                    statusView?.text = "Modo de leitura ativo. Encosta à parte traseira do telemóvel que está a apresentar o contacto."
                }
            }
        }
        val list = Button(this).apply {
            text = "Os meus contactos"
            setOnClickListener { showContacts() }
        }
        val lock = Button(this).apply { text = "Bloquear"; setOnClickListener { unlocked = false; render() } }
        show(label("TOQUE 2.0 — PROTÓTIPO NFC", 24f, true), status, share, read, list, statusView!!, lock)
    }

    private fun enableReader() {
        val a = nfc ?: return
        readerEnabled = true
        a.enableReaderMode(this, { tag -> readContact(tag) },
            NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_NFC_B or NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK,
            Bundle())
    }

    private fun disableReader() {
        if (readerEnabled) {
            nfc?.disableReaderMode(this)
            readerEnabled = false
        }
    }

    private fun readContact(tag: Tag) {
        var result: String? = null
        try {
            val iso = IsoDep.get(tag) ?: throw IllegalStateException("O equipamento não disponibilizou ISO-DEP.")
            iso.connect()
            iso.timeout = 5000
            val aid = byteArrayOf(0x00, 0xA4.toByte(), 0x04, 0x00, 0x07,
                0xF0.toByte(), 0x41, 0x50, 0x51, 0x55, 0x45, 0x01)
            val selected = iso.transceive(aid)
            if (selected.size < 2 || selected[selected.size-2] != 0x90.toByte()) throw IllegalStateException("O serviço Toque não foi encontrado.")
            val response = iso.transceive(byteArrayOf(0x80.toByte(), 0xCA.toByte(), 0x00, 0x00, 0x00))
            iso.close()
            if (response.size < 3 || response[response.size-2] != 0x90.toByte()) throw IllegalStateException("Não foi possível receber o contacto.")
            result = String(response, 0, response.size - 2, Charsets.UTF_8)
        } catch (e: Exception) {
            runOnUiThread { statusView?.text = "Falha NFC: ${e.message ?: "erro desconhecido"}" }
        }
        if (result != null) {
            val value = result!!
            runOnUiThread { askAliasAndSave(value) }
        }
    }

    private fun askAliasAndSave(payload: String) {
        disableReader()
        if (!payload.startsWith("TOQUE1:")) {
            statusView?.text = "Formato de contacto desconhecido."
            return
        }
        val key = payload.removePrefix("TOQUE1:")
        try { Base64.decode(key, Base64.DEFAULT) } catch (_: Exception) {
            statusView?.text = "Chave pública inválida."
            return
        }
        val input = EditText(this).apply { hint = "Alcunha para este contacto" }
        AlertDialogBuilder(this, input) {
            val alias = input.text.toString().trim()
            if (alias.isBlank()) { statusView?.text = "Escolhe uma alcunha para guardar o contacto."; return@AlertDialogBuilder }
            val arr = JSONArray(prefs().getString("contacts", "[]"))
            val fingerprint = MessageDigest.getInstance("SHA-256").digest(Base64.decode(key, Base64.DEFAULT))
                .joinToString("") { "%02X".format(it) }
            if ((0 until arr.length()).any { arr.getJSONObject(it).optString("fingerprint") == fingerprint }) {
                statusView?.text = "Este contacto já está guardado."
            } else {
                arr.put(JSONObject().put("alias", alias).put("publicKey", key).put("fingerprint", fingerprint))
                prefs().edit().putString("contacts", arr.toString()).apply()
                statusView?.text = "Contacto «$alias» guardado. Impressão digital: ${fingerprint.take(16)}…"
            }
            home()
        }
    }

    private fun showContacts() {
        val arr = JSONArray(prefs().getString("contacts", "[]"))
        val lines = (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            "• ${o.optString("alias")}\n  Chave: ${o.optString("fingerprint").take(24)}…"
        }
        show(label("CONTACTOS", 24f, true), label(if (lines.isEmpty()) "Ainda não tens contactos." else lines.joinToString("\n\n")),
            Button(this).apply { text = "Voltar"; setOnClickListener { home() } })
    }

    private fun prefs() = getSharedPreferences("toque_contacts", Context.MODE_PRIVATE)

    private fun show(vararg views: android.view.View) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(42, 56, 42, 32)
        }
        views.forEach { box.addView(it) }
        setContentView(ScrollView(this).apply { addView(box) })
    }

    private fun label(text: String, size: Float = 16f, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = size
        if (bold) setTypeface(null, Typeface.BOLD)
        setPadding(0, 18, 0, 18)
    }

    private fun AlertDialogBuilder(context: Context, input: EditText, onOk: () -> Unit) {
        android.app.AlertDialog.Builder(context)
            .setTitle("Guardar contacto")
            .setMessage("A alcunha só é guardada neste telemóvel.")
            .setView(input)
            .setPositiveButton("Guardar") { _, _ -> onOk() }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
