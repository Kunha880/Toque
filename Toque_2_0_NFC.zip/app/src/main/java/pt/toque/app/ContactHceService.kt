package pt.toque.app

import android.nfc.cardemulation.HostApduService
import android.os.Bundle
import android.util.Base64

class ContactHceService : HostApduService() {
    override fun processCommandApdu(commandApdu: ByteArray?, extras: Bundle?): ByteArray {
        if (commandApdu == null) return SW_ERROR
        return when {
            commandApdu.contentEquals(SELECT_AID) -> SW_OK
            commandApdu.contentEquals(GET_CONTACT) -> {
                try {
                    val key = IdentityStore.publicKey(this)
                    val payload = ("TOQUE1:" + key).toByteArray(Charsets.UTF_8)
                    if (payload.size > 240) SW_ERROR else payload + SW_OK
                } catch (_: Exception) {
                    SW_ERROR
                }
            }
            else -> SW_ERROR
        }
    }

    override fun onDeactivated(reason: Int) = Unit

    companion object {
        private val SW_OK = byteArrayOf(0x90.toByte(), 0x00)
        private val SW_ERROR = byteArrayOf(0x6F.toByte(), 0x00)
        private val SELECT_AID = byteArrayOf(
            0x00, 0xA4.toByte(), 0x04, 0x00, 0x07,
            0xF0.toByte(), 0x41, 0x50, 0x51, 0x55, 0x45, 0x01
        )
        private val GET_CONTACT = byteArrayOf(0x80.toByte(), 0xCA.toByte(), 0x00, 0x00, 0x00)
    }
}
