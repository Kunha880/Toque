# Toque 2.0 — protótipo de troca de contactos NFC

## Estado real desta entrega
Esta versão é um **protótipo de troca unidirecional de contacto público por NFC (HCE/ISO-DEP)**. Inclui PIN local, geração de identidade EC no Android Keystore, apresentação do contacto por HCE, leitura ISO-DEP, escolha de alcunha local e lista persistente de contactos.

**Ainda não inclui mensagens, Double Ratchet/libsignal, Tor, serviço de entrega, sincronização bidirecional ou auditoria de segurança.** Não usar para comunicações sensíveis. A chave pública é transmitida; não é uma sessão autenticada nem prova a identidade civil da pessoa.

## Como testar com dois Android
1. Instalar o APK nos dois telemóveis.
2. Abrir Toque em ambos e criar PIN.
3. Ativar NFC nas definições.
4. No telemóvel A, tocar em **Apresentar o meu contacto por NFC**.
5. No telemóvel B, tocar em **Ler contacto por NFC**.
6. Encostar as partes traseiras, mantendo os ecrãs ativos e desbloqueados.
7. No telemóvel B, escolher a alcunha e guardar.
8. Repetir no sentido inverso para guardar o contacto de B em A.

O serviço HCE está configurado como aplicação de cartão. O leitor usa ISO-DEP. Alguns modelos/versões podem posicionar a antena NFC em locais diferentes; retirar capas grossas e experimentar o alinhamento.

## Limitação importante
HCE não é uma troca simultânea bidirecional: nesta versão, um telemóvel apresenta e o outro lê. É necessário repetir no sentido inverso. A compatibilidade depende do suporte NFC/HCE do equipamento e da implementação do fabricante.

## Compilar no GitHub sem PC
1. Criar um repositório GitHub vazio.
2. Carregar o conteúdo desta pasta para a raiz do repositório (não carregar a pasta externa).
3. Abrir **Actions** e executar **Build Toque APK** (ou fazer push para `main`).
4. Abrir a execução concluída e descarregar o artefacto `toque-debug-apk`.
5. Extrair o ZIP do artefacto e instalar `app-debug.apk` nos dois Android.

O workflow usa Gradle 8.7 e Java 17. Não é necessário guardar chaves ou segredos no GitHub para gerar este APK de teste.
