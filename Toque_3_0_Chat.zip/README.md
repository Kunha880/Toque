# Toque 3.0 — conversas privadas entre dois Android (protótipo de teste)

## Estado real desta entrega
Construído sobre o Toque 2.0 (PIN, NFC/HCE, Keystore). **Compilar e testar em dois telemóveis ainda não foi feito**:
o primeiro build no GitHub Actions e o teste em dois Android são a validação real.

O que foi verificado antes de entregar: o núcleo de criptografia (`pt.toque.core`, Java) compilou e passou
70 verificações no PC contra o Bouncy Castle real, incluindo os vetores oficiais da RFC 7748 (X25519) e RFC 5869 (HKDF),
conversa completa, mensagens fora de ordem, perdidas, repetidas e adulteradas. Esse mesmo teste está na app
(Ferramentas → Autoteste da criptografia). O código Kotlin (interface, NFC, transporte) **não foi compilado**.

## O que tem
- PIN (mínimo 6 números) com hash PBKDF2. **À 3.ª tentativa errada apaga tudo** (chaves do Keystore, contactos, mensagens, preferências).
  O contador é gravado antes de verificar o PIN, por isso fechar a app a meio não devolve tentativas.
- Emparelhamento por NFC numa só encostada, nos dois sentidos: um toca em «Eu leio», o outro em «Eu sou lido».
  Os dois ecrãs mostram um código de 8 dígitos que as pessoas têm de comparar.
- Conversas individuais: enviar, receber, responder, histórico, hora, estados (A enviar / Enviada / Entregue / Falhou).
- Encriptação ponta a ponta: X25519 + Double Ratchet + AES-256-GCM. Cada mensagem tem exatamente 2048 bytes.
- Dados guardados num ficheiro cifrado (AES-256-GCM, chave no Android Keystore), fora das cópias de segurança.
- Notificação genérica «Nova mensagem» (só se a app ainda estiver viva em segundo plano).
- Alcunhas locais, bloquear e apagar contactos.
- Diagnóstico NFC 2.0 (o troca-contactos antigo, inalterado) em Ferramentas.

## O que NÃO tem (honestidade)
- **Sem Tor** (Toque 4.0). O transporte é o ntfy.sh por HTTPS: o servidor vê o teu IP, mas só vê texto cifrado de tamanho fixo.
- O ntfy.sh guarda mensagens poucas horas (12 h por defeito). Quem estiver offline mais tempo perde-as.
- **Sem serviço em segundo plano**: o Android pode parar a app. Para testar, mantém as duas apps abertas.
  Mensagens enviadas enquanto a outra está fechada chegam quando for aberta (dentro da janela do ntfy).
- O Double Ratchet é implementação própria da especificação da Signal (não é o libsignal) e **não foi auditado**.
- Sem criptografia pós-quântica, sem encriptação de cabeçalhos, sem base de dados SQL cifrada (usa ficheiro cifrado).
- A autenticação do emparelhamento é a presença física + comparar o código. Não há chaves de identidade.
- Sem apresentações de contactos (5.0), sem mensagens temporárias (5.0), sem fotos (6.0).
- Os contactos do 2.0 não passam para a 3.0: é preciso voltar a adicionar por NFC.

## Como testar com dois Android
1. Instalar o APK nos dois (desinstalar o Toque 2.0 antes, na primeira vez). Criar PIN em ambos.
2. Ligar o NFC e o ecrã nos dois, com a internet ativa.
3. Telemóvel A: «Adicionar contacto» → «Eu leio». Telemóvel B: «Adicionar contacto» → «Eu sou lido».
4. Encostar as costas dos telemóveis até aparecer o código. Comparar: têm de ser iguais.
5. Escolher uma alcunha em cada telemóvel (podem ser diferentes) → «É igual — guardar contacto».
6. Abrir a conversa, enviar uma mensagem de A para B, responder de B para A. Ver os estados Enviada → Entregue.
7. Experimentar: ecrã de B bloqueado/fechado e abrir depois; escrever os dois ao mesmo tempo; Autoteste.

## Compilar no GitHub sem PC
Carregar este ZIP (sem o descompactar) para a raiz do repositório, com o nome `Toque_3_0_Chat.zip`.
O workflow escolhe sozinho o ZIP `Toque_*.zip` mais recente, compila e publica `Toque.apk` numa Release.
A chave de assinatura de teste (`app/debug.keystore`) é fixa, por isso as versões seguintes instalam-se por cima.
Não usar essa chave para publicar a app.
