package pt.toque.core;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

/** Pequenas ajudas para trabalhar com bytes. */
public final class Bytes {
    private Bytes() {}

    public static byte[] utf8(String s) {
        return s.getBytes(StandardCharsets.UTF_8);
    }

    public static byte[] concat(byte[]... parts) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        for (byte[] p : parts) out.write(p, 0, p.length);
        return out.toByteArray();
    }

    public static byte[] slice(byte[] src, int from, int to) {
        byte[] r = new byte[to - from];
        System.arraycopy(src, from, r, 0, r.length);
        return r;
    }

    public static boolean equal(byte[] a, byte[] b) {
        return MessageDigest.isEqual(a, b);
    }

    public static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder(b.length * 2);
        for (byte x : b) {
            sb.append(Character.forDigit((x >> 4) & 0xf, 16));
            sb.append(Character.forDigit(x & 0xf, 16));
        }
        return sb.toString();
    }

    public static byte[] unhex(String s) {
        byte[] r = new byte[s.length() / 2];
        for (int i = 0; i < r.length; i++) {
            r[i] = (byte) ((Character.digit(s.charAt(2 * i), 16) << 4) | Character.digit(s.charAt(2 * i + 1), 16));
        }
        return r;
    }

    public static void putInt(byte[] dst, int off, int v) {
        dst[off] = (byte) (v >>> 24);
        dst[off + 1] = (byte) (v >>> 16);
        dst[off + 2] = (byte) (v >>> 8);
        dst[off + 3] = (byte) v;
    }

    public static int getInt(byte[] src, int off) {
        return ((src[off] & 0xff) << 24) | ((src[off + 1] & 0xff) << 16)
                | ((src[off + 2] & 0xff) << 8) | (src[off + 3] & 0xff);
    }

    public static void putLong(byte[] dst, int off, long v) {
        for (int i = 7; i >= 0; i--) {
            dst[off + i] = (byte) v;
            v >>>= 8;
        }
    }

    public static long getLong(byte[] src, int off) {
        long v = 0;
        for (int i = 0; i < 8; i++) v = (v << 8) | (src[off + i] & 0xff);
        return v;
    }
}
