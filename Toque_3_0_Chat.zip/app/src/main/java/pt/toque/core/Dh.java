package pt.toque.core;

import org.bouncycastle.math.ec.rfc7748.X25519;

import java.security.GeneralSecurityException;
import java.security.SecureRandom;

/** Acordo de chaves X25519 (RFC 7748) com a implementação do Bouncy Castle. */
public final class Dh {
    public static final int SIZE = 32;

    private Dh() {}

    public static final class Pair {
        public final byte[] priv;
        public final byte[] pub;

        public Pair(byte[] priv, byte[] pub) {
            this.priv = priv;
            this.pub = pub;
        }
    }

    public static Pair generate(SecureRandom rnd) {
        byte[] priv = new byte[SIZE];
        X25519.generatePrivateKey(rnd, priv);
        byte[] pub = new byte[SIZE];
        X25519.generatePublicKey(priv, 0, pub, 0);
        return new Pair(priv, pub);
    }

    public static byte[] agree(byte[] priv, byte[] pub) throws GeneralSecurityException {
        if (priv == null || pub == null || priv.length != SIZE || pub.length != SIZE) {
            throw new GeneralSecurityException("tamanho de chave invalido");
        }
        byte[] out = new byte[SIZE];
        // devolve false se o resultado for todo a zeros (ponto de ordem baixa)
        if (!X25519.calculateAgreement(priv, 0, pub, 0, out, 0)) {
            throw new GeneralSecurityException("acordo de chaves invalido");
        }
        return out;
    }
}
