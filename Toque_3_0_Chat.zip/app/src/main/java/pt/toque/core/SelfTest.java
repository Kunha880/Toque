package pt.toque.core;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Autoteste da criptografia. Corre no PC (main) e dentro da app (botao "Autoteste").
 * Devolve um relatorio; lanca excecao se alguma verificacao falhar.
 */
public final class SelfTest {
    private SelfTest() {}

    private static final SecureRandom RNG = new SecureRandom();
    private static int checks;
    private static final List<String> LOG = new ArrayList<String>();

    private static void check(boolean cond, String what) {
        checks++;
        if (!cond) throw new IllegalStateException("FALHOU: " + what);
        LOG.add("ok  " + what);
    }

    private static byte[] pad(String s) throws GeneralSecurityException {
        byte[] id = new byte[8];
        RNG.nextBytes(id);
        return new Frame(Frame.TEXT, id, 1L, s.getBytes(StandardCharsets.UTF_8)).encode();
    }

    private static String text(byte[] plain) throws GeneralSecurityException {
        return new String(Frame.decode(plain).payload, StandardCharsets.UTF_8);
    }

    private static boolean fails(Runnable0 r) {
        try {
            r.run();
            return false;
        } catch (Exception e) {
            return true;
        }
    }

    private interface Runnable0 {
        void run() throws Exception;
    }

    public static String run() throws Exception {
        checks = 0;
        LOG.clear();

        // 1. X25519: vetor de teste da RFC 7748, seccao 6.1
        byte[] a = Bytes.unhex("77076d0a7318a57d3c16c17251b26645df4c2f87ebc0992ab177fba51db92c2a");
        byte[] bPub = Bytes.unhex("de9edb7d7b7dc1b4d35b61c2ece435373f8343c85b78674dadfc7e146f882b4f");
        byte[] k = Dh.agree(a, bPub);
        check(Bytes.hex(k).equals("4a5d9d5ba4ce2de1728e3bf480350f25e07e21c947d19e3376f09b3c1e161742"),
                "X25519 igual ao vetor da RFC 7748");
        check(fails(new Runnable0() {
            public void run() throws Exception {
                Dh.agree(new byte[32], new byte[32]);
            }
        }), "X25519 rejeita ponto de ordem baixa (zeros)");

        // 2. HKDF: vetor de teste 1 da RFC 5869
        byte[] ikm = new byte[22];
        Arrays.fill(ikm, (byte) 0x0b);
        byte[] salt = Bytes.unhex("000102030405060708090a0b0c");
        byte[] info = Bytes.unhex("f0f1f2f3f4f5f6f7f8f9");
        check(Bytes.hex(Kdf.hkdf(salt, ikm, info, 42)).equals(
                "3cb25f25faacd57a90434f64d0362f2a2d2d0a90cf1a5a4c5db02d56ecc4c5bf34007208d5b887185865"),
                "HKDF-SHA256 igual ao vetor da RFC 5869");

        // 3. Emparelhamento: os dois lados chegam ao mesmo resultado
        Handshake.Initiator ini = new Handshake.Initiator();
        Handshake.Responded rsp = Handshake.respond(ini.message1());
        Handshake.Result rr = ini.finish(rsp.message2);
        Handshake.Result hh = rsp.result;
        check(rr.code.equals(hh.code), "codigo de verificacao igual nos dois lados (" + rr.code + ")");
        check(rr.fingerprint.equals(hh.fingerprint), "impressao digital igual nos dois lados");
        check(rr.topicOut.equals(hh.topicIn) && rr.topicIn.equals(hh.topicOut), "topicos de entrega espelhados");
        check(!rr.topicOut.equals(rr.topicIn), "topico de envio diferente do de receber");
        check(rr.topicOut.length() == 34, "nome de topico com 34 caracteres");
        Handshake.Initiator ini2 = new Handshake.Initiator();
        Handshake.Result other = ini2.finish(Handshake.respond(ini2.message1()).message2);
        check(!other.code.equals(rr.code) && !other.topicOut.equals(rr.topicOut), "cada emparelhamento e diferente");
        check(fails(new Runnable0() {
            public void run() throws Exception {
                Handshake.respond(new byte[99]);
            }
        }), "mensagem 1 invalida e rejeitada");

        // 4. Double Ratchet: conversa completa
        Ratchet alice = rr.ratchet;   // o que le
        Ratchet bob = hh.ratchet;     // o que e lido
        byte[] e1 = alice.encrypt(pad("ola do Alice"));
        check(e1.length == Ratchet.ENVELOPE_SIZE, "envelope com tamanho fixo (" + e1.length + " bytes)");
        check(text(bob.decrypt(e1)).equals("ola do Alice"), "mensagem 1 (leitor -> lido)");
        byte[] e2 = bob.encrypt(pad("ola do Bob"));
        check(text(alice.decrypt(e2)).equals("ola do Bob"), "resposta (lido -> leitor)");

        // quem e lido tambem pode escrever primeiro e as duas partes podem escrever ao mesmo tempo
        Handshake.Initiator i3 = new Handshake.Initiator();
        Handshake.Responded r3 = Handshake.respond(i3.message1());
        Handshake.Result a3 = i3.finish(r3.message2);
        Ratchet al = a3.ratchet;
        Ratchet bo = r3.result.ratchet;
        byte[] bFirst = bo.encrypt(pad("Bob escreve primeiro"));
        check(text(al.decrypt(bFirst)).equals("Bob escreve primeiro"), "o telemovel lido pode escrever primeiro");
        byte[] simA = al.encrypt(pad("simultanea A"));
        byte[] simB = bo.encrypt(pad("simultanea B"));
        check(text(bo.decrypt(simA)).equals("simultanea A") && text(al.decrypt(simB)).equals("simultanea B"),
                "mensagens simultaneas cruzam-se bem");

        // varias mensagens seguidas, fora de ordem e com perdas
        byte[][] burst = new byte[6][];
        for (int i = 0; i < burst.length; i++) burst[i] = alice.encrypt(pad("rajada " + i));
        check(text(bob.decrypt(burst[3])).equals("rajada 3"), "mensagem 3 recebida antes das 0, 1 e 2");
        check(text(bob.decrypt(burst[0])).equals("rajada 0"), "mensagem 0 chega depois (chave guardada)");
        check(text(bob.decrypt(burst[5])).equals("rajada 5"), "salto para a mensagem 5 (a 4 perdeu-se)");
        check(text(bob.decrypt(burst[1])).equals("rajada 1"), "mensagem 1 chega tarde");
        check(text(bob.decrypt(burst[2])).equals("rajada 2"), "mensagem 2 chega tarde");

        // 5. Seguranca: repeticao, adulteracao, e o estado nao muda se falhar
        final Ratchet bobRef = bob;
        final byte[] replay = burst[3];
        check(fails(new Runnable0() {
            public void run() throws Exception {
                bobRef.decrypt(replay);
            }
        }), "repeticao de uma mensagem e rejeitada");
        byte[] fresh = alice.encrypt(pad("depois das falhas"));
        byte[] tampered = fresh.clone();
        tampered[100] ^= 0x01;
        final byte[] tamperedF = tampered;
        check(fails(new Runnable0() {
            public void run() throws Exception {
                bobRef.decrypt(tamperedF);
            }
        }), "mensagem adulterada e rejeitada");
        byte[] header = fresh.clone();
        header[10] ^= 0x01;
        final byte[] headerF = header;
        check(fails(new Runnable0() {
            public void run() throws Exception {
                bobRef.decrypt(headerF);
            }
        }), "cabecalho adulterado e rejeitado");
        check(text(bob.decrypt(fresh)).equals("depois das falhas"),
                "apos falhas o estado ficou intacto e a mensagem boa passa");

        // 6. Guardar e repor o estado a meio da conversa
        byte[] saved = bob.serialize();
        Ratchet bob2 = Ratchet.deserialize(saved);
        byte[] more = alice.encrypt(pad("depois de reiniciar"));
        check(text(bob2.decrypt(more)).equals("depois de reiniciar"), "estado guardado e reposto continua a funcionar");
        byte[] back = bob2.encrypt(pad("resposta apos reposicao"));
        check(text(alice.decrypt(back)).equals("resposta apos reposicao"), "resposta depois de repor o estado");

        // 7. Conversa longa com muitas trocas de direcao
        for (int i = 0; i < 40; i++) {
            Ratchet s = (i % 2 == 0) ? alice : bob2;
            Ratchet r = (i % 2 == 0) ? bob2 : alice;
            String msg = "troca " + i;
            check(text(r.decrypt(s.encrypt(pad(msg)))).equals(msg), "troca " + i + " (ping-pong)");
        }

        // 8. Tamanhos
        StringBuilder big = new StringBuilder();
        while (big.length() < Frame.MAX_PAYLOAD) big.append('x');
        String max = big.toString();
        check(text(alice.decrypt(bob2.encrypt(pad("")))).equals(""), "mensagem vazia");
        check(text(bob2.decrypt(alice.encrypt(pad(max)))).equals(max), "mensagem com o tamanho maximo (" + Frame.MAX_PAYLOAD + ")");
        final String tooBig = max + "y";
        check(fails(new Runnable0() {
            public void run() throws Exception {
                pad(tooBig);
            }
        }), "mensagem acima do maximo e recusada");
        check(Frame.decode(pad("acentuacao: cao, coracao, ola")).type == Frame.TEXT, "formato da mensagem");

        return "AUTOTESTE OK: " + checks + " verificacoes\n" + join(LOG);
    }

    private static String join(List<String> l) {
        StringBuilder sb = new StringBuilder();
        for (String s : l) sb.append(s).append('\n');
        return sb.toString();
    }

    public static void main(String[] args) throws Exception {
        System.out.println(run());
    }
}
