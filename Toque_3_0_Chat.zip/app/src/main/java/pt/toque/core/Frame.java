package pt.toque.core;

import java.security.GeneralSecurityException;

/**
 * Conteudo (antes de cifrar) de cada mensagem, sempre com PLAINTEXT_SIZE bytes:
 * [tipo 1][id 8][hora 8][tamanho 2][dados...][zeros ate ao fim]
 */
public final class Frame {
    public static final byte TEXT = 1;
    public static final byte ACK = 2;
    private static final int FIXED = 1 + 8 + 8 + 2;
    public static final int MAX_PAYLOAD = Ratchet.PLAINTEXT_SIZE - FIXED;

    public final byte type;
    public final byte[] id;      // 8 bytes
    public final long time;      // milissegundos desde 1970 (hora do remetente)
    public final byte[] payload;

    public Frame(byte type, byte[] id, long time, byte[] payload) {
        this.type = type;
        this.id = id;
        this.time = time;
        this.payload = payload;
    }

    public byte[] encode() throws GeneralSecurityException {
        if (id.length != 8) throw new GeneralSecurityException("id invalido");
        if (payload.length > MAX_PAYLOAD) throw new GeneralSecurityException("mensagem demasiado longa");
        byte[] out = new byte[Ratchet.PLAINTEXT_SIZE];
        out[0] = type;
        System.arraycopy(id, 0, out, 1, 8);
        Bytes.putLong(out, 9, time);
        out[17] = (byte) (payload.length >>> 8);
        out[18] = (byte) payload.length;
        System.arraycopy(payload, 0, out, FIXED, payload.length);
        return out;
    }

    public static Frame decode(byte[] plain) throws GeneralSecurityException {
        if (plain.length != Ratchet.PLAINTEXT_SIZE) throw new GeneralSecurityException("tamanho invalido");
        byte type = plain[0];
        if (type != TEXT && type != ACK) throw new GeneralSecurityException("tipo desconhecido");
        int len = ((plain[17] & 0xff) << 8) | (plain[18] & 0xff);
        if (len > MAX_PAYLOAD) throw new GeneralSecurityException("tamanho invalido");
        return new Frame(type, Bytes.slice(plain, 1, 9), Bytes.getLong(plain, 9),
                Bytes.slice(plain, FIXED, FIXED + len));
    }
}
