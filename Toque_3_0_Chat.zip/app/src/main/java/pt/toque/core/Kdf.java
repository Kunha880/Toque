package pt.toque.core;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.ByteArrayOutputStream;
import java.security.MessageDigest;

/** HMAC-SHA256, HKDF-SHA256 (RFC 5869) e SHA-256. */
public final class Kdf {
    private Kdf() {}

    public static byte[] sha256(byte[]... parts) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            for (byte[] p : parts) md.update(p);
            return md.digest();
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    public static byte[] hmac(byte[] key, byte[]... parts) {
        try {
            byte[] k = key.length == 0 ? new byte[32] : key;
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(k, "HmacSHA256"));
            for (byte[] p : parts) mac.update(p);
            return mac.doFinal();
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    public static byte[] hkdf(byte[] salt, byte[] ikm, byte[] info, int length) {
        byte[] prk = hmac(salt.length == 0 ? new byte[32] : salt, ikm);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] t = new byte[0];
        int i = 1;
        while (out.size() < length) {
            t = hmac(prk, t, info, new byte[]{(byte) i});
            out.write(t, 0, t.length);
            i++;
        }
        return Bytes.slice(out.toByteArray(), 0, length);
    }
}
