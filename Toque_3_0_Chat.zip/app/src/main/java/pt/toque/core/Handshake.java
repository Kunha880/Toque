package pt.toque.core;

import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.Base64;

/**
 * Emparelhamento presencial por NFC, numa unica ida-e-volta:
 *   leitor (initiator) -> mensagem 1: "TQ3" | nonce(32) | X(32) | R(32)   (99 bytes)
 *   telemovel lido (responder) -> mensagem 2: nonce(32) | X(32) | R(32)   (96 bytes)
 * X = chave efemera X25519 do acordo; R = chave inicial do Double Ratchet.
 * Ambos calculam: segredo de sessao, chaves do Double Ratchet, topicos de entrega
 * e um codigo de verificacao que as duas pessoas comparam nos ecras.
 * Nao ha chaves de identidade: a autenticacao e a presenca fisica + o codigo.
 */
public final class Handshake {
    public static final int MSG1_SIZE = 3 + 32 + 32 + 32;
    public static final int MSG2_SIZE = 32 + 32 + 32;
    private static final byte[] MAGIC = new byte[]{'T', 'Q', '3'};
    private static final SecureRandom RNG = new SecureRandom();

    private Handshake() {}

    public static final class Result {
        public final boolean initiator;
        public final Ratchet ratchet;
        public final String code;         // por exemplo "1234 5678"
        public final String fingerprint;  // 64 caracteres hexadecimais, igual nos dois lados
        public final String topicOut;     // onde EU publico
        public final String topicIn;      // onde EU escuto

        Result(boolean initiator, Ratchet ratchet, String code, String fingerprint, String topicOut, String topicIn) {
            this.initiator = initiator;
            this.ratchet = ratchet;
            this.code = code;
            this.fingerprint = fingerprint;
            this.topicOut = topicOut;
            this.topicIn = topicIn;
        }
    }

    public static final class Responded {
        public final byte[] message2;
        public final Result result;

        Responded(byte[] message2, Result result) {
            this.message2 = message2;
            this.result = result;
        }
    }

    public static final class Initiator {
        private final byte[] nonce = new byte[32];
        private final Dh.Pair x = Dh.generate(RNG);
        private final Dh.Pair r = Dh.generate(RNG);
        private final byte[] msg1;

        public Initiator() {
            RNG.nextBytes(nonce);
            msg1 = Bytes.concat(MAGIC, nonce, x.pub, r.pub);
        }

        public byte[] message1() {
            return msg1.clone();
        }

        public Result finish(byte[] msg2) throws GeneralSecurityException {
            if (msg2.length != MSG2_SIZE) throw new GeneralSecurityException("resposta invalida");
            byte[] theirX = Bytes.slice(msg2, 32, 64);
            byte[] theirR = Bytes.slice(msg2, 64, 96);
            return derive(true, msg1, msg2, x, theirX, r, theirR);
        }
    }

    public static Responded respond(byte[] msg1) throws GeneralSecurityException {
        if (msg1.length != MSG1_SIZE || msg1[0] != 'T' || msg1[1] != 'Q' || msg1[2] != '3') {
            throw new GeneralSecurityException("pedido invalido");
        }
        byte[] theirX = Bytes.slice(msg1, 35, 67);
        byte[] theirR = Bytes.slice(msg1, 67, 99);
        byte[] nonce = new byte[32];
        RNG.nextBytes(nonce);
        Dh.Pair x = Dh.generate(RNG);
        Dh.Pair r = Dh.generate(RNG);
        byte[] msg2 = Bytes.concat(nonce, x.pub, r.pub);
        Result res = derive(false, msg1, msg2, x, theirX, r, theirR);
        return new Responded(msg2, res);
    }

    private static Result derive(boolean initiator, byte[] msg1, byte[] msg2, Dh.Pair myX, byte[] theirX,
                                 Dh.Pair myR, byte[] theirR) throws GeneralSecurityException {
        byte[] dh = Dh.agree(myX.priv, theirX);
        byte[] transcript = Kdf.sha256(Bytes.utf8("Toque/3/transcript"), msg1, msg2);
        byte[] salt = Bytes.concat(Bytes.slice(msg1, 3, 35), Bytes.slice(msg2, 0, 32));
        byte[] sk = Kdf.hkdf(salt, dh, Bytes.concat(Bytes.utf8("Toque/3/SK"), transcript), 32);

        Ratchet ratchet = initiator
                ? Ratchet.initInitiator(sk, transcript, myR, theirR)
                : Ratchet.initResponder(sk, transcript, myR, theirR);

        byte[] v = Kdf.hmac(sk, Bytes.utf8("Toque/3/verify"), transcript);
        int n = (Bytes.getInt(v, 0) & 0x7fffffff) % 100000000;
        String digits = String.format("%08d", n);
        String code = digits.substring(0, 4) + " " + digits.substring(4);

        String r2h = topic(sk, "Toque/3/topic/R2H");
        String h2r = topic(sk, "Toque/3/topic/H2R");
        return new Result(initiator, ratchet, code, Bytes.hex(transcript),
                initiator ? r2h : h2r, initiator ? h2r : r2h);
    }

    private static String topic(byte[] sk, String label) {
        byte[] t = Kdf.hkdf(new byte[32], sk, Bytes.utf8(label), 24);
        return "tq" + Base64.getUrlEncoder().withoutPadding().encodeToString(t);
    }
}
