package pt.toque.core;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.GeneralSecurityException;

/**
 * AES-256-GCM. Cada chave de mensagem (mk) so e usada uma vez, por isso a chave
 * e o IV sao derivados dela por HKDF (o IV deterministico e seguro nesse caso).
 */
public final class Aead {
    private static final byte[] INFO = Bytes.utf8("Toque/3/MK");

    private Aead() {}

    private static Cipher cipher(int mode, byte[] mk, byte[] aad) throws GeneralSecurityException {
        byte[] okm = Kdf.hkdf(new byte[32], mk, INFO, 44);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(mode, new SecretKeySpec(Bytes.slice(okm, 0, 32), "AES"),
                new GCMParameterSpec(128, Bytes.slice(okm, 32, 44)));
        c.updateAAD(aad);
        return c;
    }

    public static byte[] encrypt(byte[] mk, byte[] aad, byte[] plain) throws GeneralSecurityException {
        return cipher(Cipher.ENCRYPT_MODE, mk, aad).doFinal(plain);
    }

    public static byte[] decrypt(byte[] mk, byte[] aad, byte[] ct) throws GeneralSecurityException {
        return cipher(Cipher.DECRYPT_MODE, mk, aad).doFinal(ct);
    }
}
