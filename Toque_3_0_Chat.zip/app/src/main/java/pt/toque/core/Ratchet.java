package pt.toque.core;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Double Ratchet conforme a especificacao publica da Signal
 * (https://signal.org/docs/specifications/doubleratchet/), com:
 *  - DH: X25519 | KDF_RK: HKDF-SHA256 | KDF_CK: HMAC-SHA256 | AEAD: AES-256-GCM
 *  - mensagens com tamanho fixo (ENVELOPE_SIZE)
 *  - descodificacao transacional: se falhar, o estado nao muda
 *
 * Inicializacao simetrica (ambos podem enviar logo apos o toque NFC):
 *  - o "initiator" (telemovel que le) comeca com chave de envio = a sua chave de ratchet do toque;
 *  - o "responder" (telemovel que e lido) faz logo o passo de receber e depois um passo de enviar.
 * NAO e a biblioteca da Signal: e uma implementacao propria da especificacao, sem auditoria.
 */
public final class Ratchet {
    public static final int ENVELOPE_SIZE = 2048;
    private static final int VERSION = 3;
    private static final int HEADER_SIZE = 1 + 32 + 4 + 4;
    private static final int TAG_SIZE = 16;
    public static final int PLAINTEXT_SIZE = ENVELOPE_SIZE - HEADER_SIZE - TAG_SIZE; // 1991

    private static final int MAX_SKIP = 500;
    private static final int MAX_STORED = 1000;
    private static final byte[] INFO_RK = Bytes.utf8("Toque/3/RK");
    private static final SecureRandom RNG = new SecureRandom();

    private byte[] dhsPriv;
    private byte[] dhsPub;
    private byte[] dhr;   // pode ser null
    private byte[] rk;
    private byte[] cks;   // pode ser null
    private byte[] ckr;   // pode ser null
    private byte[] ad;
    private int ns;
    private int nr;
    private int pn;
    private LinkedHashMap<String, byte[]> skipped = new LinkedHashMap<String, byte[]>();

    private Ratchet() {}

    // ---------- inicializacao ----------

    public static Ratchet initInitiator(byte[] sk, byte[] ad, Dh.Pair myRatchet, byte[] theirRatchetPub)
            throws GeneralSecurityException {
        Ratchet r = new Ratchet();
        r.ad = ad.clone();
        r.dhsPriv = myRatchet.priv.clone();
        r.dhsPub = myRatchet.pub.clone();
        r.dhr = theirRatchetPub.clone();
        byte[] out = kdfRk(sk, Dh.agree(r.dhsPriv, r.dhr));
        r.rk = Bytes.slice(out, 0, 32);
        r.cks = Bytes.slice(out, 32, 64);
        return r;
    }

    public static Ratchet initResponder(byte[] sk, byte[] ad, Dh.Pair myRatchet, byte[] theirRatchetPub)
            throws GeneralSecurityException {
        Ratchet r = new Ratchet();
        r.ad = ad.clone();
        // passo "receber": mesma saida que o initiator calculou para enviar
        byte[] out1 = kdfRk(sk, Dh.agree(myRatchet.priv, theirRatchetPub));
        byte[] rk1 = Bytes.slice(out1, 0, 32);
        r.ckr = Bytes.slice(out1, 32, 64);
        r.dhr = theirRatchetPub.clone();
        // passo "enviar": chave nova, para poder enviar logo
        Dh.Pair fresh = Dh.generate(RNG);
        byte[] out2 = kdfRk(rk1, Dh.agree(fresh.priv, r.dhr));
        r.rk = Bytes.slice(out2, 0, 32);
        r.cks = Bytes.slice(out2, 32, 64);
        r.dhsPriv = fresh.priv;
        r.dhsPub = fresh.pub;
        return r;
    }

    // ---------- KDFs ----------

    private static byte[] kdfRk(byte[] rk, byte[] dhOut) {
        return Kdf.hkdf(rk, dhOut, INFO_RK, 64);
    }

    private static final byte[] ONE = new byte[]{0x01};
    private static final byte[] TWO = new byte[]{0x02};

    // ---------- cifrar ----------

    public synchronized byte[] encrypt(byte[] plaintext) throws GeneralSecurityException {
        if (plaintext.length != PLAINTEXT_SIZE) throw new GeneralSecurityException("tamanho de texto invalido");
        if (cks == null) throw new GeneralSecurityException("sem cadeia de envio");
        byte[] mk = Kdf.hmac(cks, ONE);
        cks = Kdf.hmac(cks, TWO);
        byte[] header = new byte[HEADER_SIZE];
        header[0] = (byte) VERSION;
        System.arraycopy(dhsPub, 0, header, 1, 32);
        Bytes.putInt(header, 33, pn);
        Bytes.putInt(header, 37, ns);
        byte[] ct = Aead.encrypt(mk, Bytes.concat(ad, header), plaintext);
        ns++;
        return Bytes.concat(header, ct);
    }

    // ---------- decifrar (transacional) ----------

    public synchronized byte[] decrypt(byte[] envelope) throws GeneralSecurityException {
        if (envelope.length != ENVELOPE_SIZE || envelope[0] != VERSION) {
            throw new GeneralSecurityException("envelope invalido");
        }
        Ratchet work;
        try {
            work = deserialize(serialize());
        } catch (IOException e) {
            throw new GeneralSecurityException(e);
        }
        byte[] plain = work.decryptInternal(envelope);
        assign(work);
        return plain;
    }

    private byte[] decryptInternal(byte[] env) throws GeneralSecurityException {
        byte[] header = Bytes.slice(env, 0, HEADER_SIZE);
        byte[] ct = Bytes.slice(env, HEADER_SIZE, env.length);
        byte[] dh = Bytes.slice(header, 1, 33);
        int pnH = Bytes.getInt(header, 33);
        int nH = Bytes.getInt(header, 37);
        if (pnH < 0 || nH < 0) throw new GeneralSecurityException("contadores invalidos");
        byte[] aad = Bytes.concat(ad, header);

        byte[] stored = skipped.remove(skipKey(dh, nH));
        if (stored != null) {
            return Aead.decrypt(stored, aad, ct);
        }
        if (dhr == null || !Arrays.equals(dh, dhr)) {
            skipMessageKeys(pnH);
            dhRatchet(dh);
        }
        skipMessageKeys(nH);
        if (ckr == null) throw new GeneralSecurityException("sem cadeia de receber");
        byte[] mk = Kdf.hmac(ckr, ONE);
        ckr = Kdf.hmac(ckr, TWO);
        nr++;
        return Aead.decrypt(mk, aad, ct);
    }

    private void skipMessageKeys(int until) throws GeneralSecurityException {
        if (nr + MAX_SKIP < until) throw new GeneralSecurityException("demasiadas mensagens em falta");
        if (ckr == null) return;
        while (nr < until) {
            byte[] mk = Kdf.hmac(ckr, ONE);
            ckr = Kdf.hmac(ckr, TWO);
            skipped.put(skipKey(dhr, nr), mk);
            nr++;
        }
        while (skipped.size() > MAX_STORED) {
            Iterator<Map.Entry<String, byte[]>> it = skipped.entrySet().iterator();
            it.next();
            it.remove();
        }
    }

    private void dhRatchet(byte[] newDhr) throws GeneralSecurityException {
        pn = ns;
        ns = 0;
        nr = 0;
        dhr = newDhr.clone();
        byte[] out = kdfRk(rk, Dh.agree(dhsPriv, dhr));
        rk = Bytes.slice(out, 0, 32);
        ckr = Bytes.slice(out, 32, 64);
        Dh.Pair fresh = Dh.generate(RNG);
        dhsPriv = fresh.priv;
        dhsPub = fresh.pub;
        byte[] out2 = kdfRk(rk, Dh.agree(dhsPriv, dhr));
        rk = Bytes.slice(out2, 0, 32);
        cks = Bytes.slice(out2, 32, 64);
    }

    private static String skipKey(byte[] dh, int n) {
        return Bytes.hex(dh) + ":" + n;
    }

    private void assign(Ratchet o) {
        dhsPriv = o.dhsPriv;
        dhsPub = o.dhsPub;
        dhr = o.dhr;
        rk = o.rk;
        cks = o.cks;
        ckr = o.ckr;
        ad = o.ad;
        ns = o.ns;
        nr = o.nr;
        pn = o.pn;
        skipped = o.skipped;
    }

    // ---------- serializacao (para guardar no armazenamento encriptado) ----------

    public synchronized byte[] serialize() throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bos);
        out.writeByte(1);
        writeArr(out, dhsPriv);
        writeArr(out, dhsPub);
        writeArr(out, dhr);
        writeArr(out, rk);
        writeArr(out, cks);
        writeArr(out, ckr);
        writeArr(out, ad);
        out.writeInt(ns);
        out.writeInt(nr);
        out.writeInt(pn);
        out.writeInt(skipped.size());
        for (Map.Entry<String, byte[]> e : skipped.entrySet()) {
            out.writeUTF(e.getKey());
            writeArr(out, e.getValue());
        }
        out.flush();
        return bos.toByteArray();
    }

    public static Ratchet deserialize(byte[] data) throws IOException {
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(data));
        int v = in.readUnsignedByte();
        if (v != 1) throw new IOException("versao de estado desconhecida");
        Ratchet r = new Ratchet();
        r.dhsPriv = readArr(in);
        r.dhsPub = readArr(in);
        r.dhr = readArr(in);
        r.rk = readArr(in);
        r.cks = readArr(in);
        r.ckr = readArr(in);
        r.ad = readArr(in);
        r.ns = in.readInt();
        r.nr = in.readInt();
        r.pn = in.readInt();
        int n = in.readInt();
        for (int i = 0; i < n; i++) {
            String k = in.readUTF();
            r.skipped.put(k, readArr(in));
        }
        return r;
    }

    private static void writeArr(DataOutputStream out, byte[] a) throws IOException {
        if (a == null) {
            out.writeInt(-1);
        } else {
            out.writeInt(a.length);
            out.write(a);
        }
    }

    private static byte[] readArr(DataInputStream in) throws IOException {
        int n = in.readInt();
        if (n < 0) return null;
        if (n > 4096) throw new IOException("estado corrompido");
        byte[] a = new byte[n];
        in.readFully(a);
        return a;
    }
}
