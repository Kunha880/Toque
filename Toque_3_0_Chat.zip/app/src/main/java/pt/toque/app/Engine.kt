package pt.toque.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Base64
import pt.toque.core.Bytes
import pt.toque.core.Frame
import pt.toque.core.Handshake
import pt.toque.core.Ratchet
import java.security.SecureRandom
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

data class ContactView(
    val id: String,
    val alias: String,
    val unread: Int,
    val blocked: Boolean,
    val fingerprint: String,
    val lastText: String?,
    val lastTime: Long
)

data class MsgView(
    val id: String,
    val outgoing: Boolean,
    val time: Long,
    val text: String,
    val state: Int
)

/**
 * Logica das conversas. Todas as alteracoes passam por uma unica thread (io) e o estado
 * e protegido por "lock"; a interface so ve copias (ContactView/MsgView).
 */
object Engine {
    private val lock = Any()
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val rng = SecureRandom()
    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val ratchets = HashMap<String, Ratchet>()
    private var app: Context? = null
    private var store: Store? = null

    /** Conversa aberta no ecra (para nao contar como nao lida). */
    @Volatile
    var openChat: String? = null

    @Volatile
    var loadError: String? = null

    fun init(ctx: Context) {
        synchronized(lock) {
            if (app == null) app = ctx.applicationContext
            if (store == null) {
                store = try {
                    Store.load(app!!)
                } catch (e: Exception) {
                    loadError = e.javaClass.simpleName
                    Store(app!!)
                }
            }
        }
        Relay.onMessage = { topic, id, time, msg -> io.execute { handleIncoming(topic, id, time, msg) } }
        Relay.onTick = { io.execute { flushOutbox() } }
        Relay.onStatus = { notifyUi() }
        restartRelay(null)
        // Aquece a criptografia (a primeira chave X25519 demora mais): assim o toque NFC e rapido
        Thread {
            try {
                pt.toque.core.Dh.generate(rng)
            } catch (_: Exception) {
            }
        }.start()
    }

    fun addListener(l: () -> Unit) {
        listeners.add(l)
    }

    fun removeListener(l: () -> Unit) {
        listeners.remove(l)
    }

    private fun notifyUi() {
        main.post { for (l in listeners) l() }
    }

    private fun restartRelay(sinceOverride: Long?) {
        val plan: Pair<List<String>, Long>? = synchronized(lock) {
            val s = store
            if (s == null) {
                null
            } else {
                val since = sinceOverride ?: (if (s.lastTs > 0) s.lastTs - 5 else 0L)
                Pair(s.contacts.map { it.topicIn }, since)
            }
        }
        if (plan != null) Relay.start(plan.first, plan.second)
    }

    // ---------- leitura (para a interface) ----------

    fun relayStatus(): String = Relay.status

    fun contacts(): List<ContactView> {
        return synchronized(lock) {
            val s = store
            if (s == null) {
                emptyList<ContactView>()
            } else {
                s.contacts.map { c ->
                    val last = s.messages[c.id]?.lastOrNull()
                    ContactView(c.id, c.alias, c.unread, c.blocked, c.fingerprint, last?.text, last?.time ?: c.created)
                }.sortedByDescending { it.lastTime }
            }
        }
    }

    fun contact(id: String): ContactView? = contacts().firstOrNull { it.id == id }

    fun messages(id: String): List<MsgView> {
        return synchronized(lock) {
            val s = store
            val list = if (s == null) null else s.messages[id]
            if (list == null) {
                emptyList<MsgView>()
            } else {
                list.map { MsgView(it.id, it.outgoing, it.time, it.text, it.state) }
            }
        }
    }

    // ---------- alteracoes ----------

    fun addContact(res: Handshake.Result, alias: String, done: (Boolean) -> Unit) {
        io.execute {
            var ok = false
            synchronized(lock) {
                val s = store
                if (s != null) {
                    val id = res.fingerprint.substring(0, 16)
                    if (s.contact(id) == null) {
                        val c = Contact(
                            id, alias, res.fingerprint, res.topicOut, res.topicIn,
                            System.currentTimeMillis(), false, 0, res.ratchet.serialize()
                        )
                        ratchets[id] = res.ratchet
                        s.contacts.add(c)
                        saveQuiet(s)
                        ok = true
                    }
                }
            }
            if (ok) {
                // buscar tambem os ultimos 10 minutos: o outro lado pode ter escrito logo apos o toque
                restartRelay(System.currentTimeMillis() / 1000 - 600)
                notifyUi()
            }
            main.post { done(ok) }
        }
    }

    fun rename(id: String, alias: String) {
        io.execute {
            synchronized(lock) {
                val s = store
                val c = s?.contact(id)
                if (s != null && c != null) {
                    c.alias = alias
                    saveQuiet(s)
                }
            }
            notifyUi()
        }
    }

    fun setBlocked(id: String, blocked: Boolean) {
        io.execute {
            synchronized(lock) {
                val s = store
                val c = s?.contact(id)
                if (s != null && c != null) {
                    c.blocked = blocked
                    saveQuiet(s)
                }
            }
            notifyUi()
        }
    }

    fun markRead(id: String) {
        io.execute {
            synchronized(lock) {
                val s = store
                val c = s?.contact(id)
                if (s != null && c != null && c.unread != 0) {
                    c.unread = 0
                    saveQuiet(s)
                }
            }
        }
    }

    /** Apaga o contacto, a chave da conversa, as mensagens e o que estava por enviar. */
    fun remove(id: String) {
        io.execute {
            synchronized(lock) {
                val s = store
                if (s != null) {
                    s.contacts.removeAll { it.id == id }
                    s.messages.remove(id)
                    s.outbox.removeAll { it.contactId == id }
                    ratchets.remove(id)
                    saveQuiet(s)
                }
            }
            restartRelay(null)
            notifyUi()
        }
    }

    fun send(contactId: String, text: String) {
        io.execute {
            synchronized(lock) {
                val s = store
                val c = s?.contact(contactId)
                if (s != null && c != null) {
                    val payload = text.toByteArray(Charsets.UTF_8)
                    if (payload.isNotEmpty() && payload.size <= Frame.MAX_PAYLOAD) {
                        val id = ByteArray(8)
                        rng.nextBytes(id)
                        val now = System.currentTimeMillis()
                        if (encryptLocked(s, c, Frame.TEXT, id, now, payload, Bytes.hex(id))) {
                            s.msgs(c.id).add(Msg(Bytes.hex(id), true, now, text, 0))
                            saveQuiet(s)
                        }
                    }
                }
            }
            notifyUi()
            flushOutbox()
        }
    }

    /** Limpa o estado em memoria (usado no apagamento total). */
    fun reset() {
        Relay.stop()
        synchronized(lock) {
            ratchets.clear()
            val a = app
            store = if (a != null) Store(a) else null
            loadError = null
        }
        openChat = null
        notifyUi()
    }

    // ---------- internos (sempre na thread io) ----------

    private fun saveQuiet(s: Store) {
        try {
            s.save()
        } catch (_: Exception) {
        }
    }

    private fun ratchetFor(c: Contact): Ratchet {
        val r = ratchets[c.id]
        if (r != null) return r
        val n = Ratchet.deserialize(c.ratchet)
        ratchets[c.id] = n
        return n
    }

    /** Cifra e poe na fila de envio. Chamar com o lock. Nao grava. */
    private fun encryptLocked(
        s: Store, c: Contact, type: Byte, id: ByteArray, time: Long, payload: ByteArray, msgId: String?
    ): Boolean {
        return try {
            val r = ratchetFor(c)
            val env = r.encrypt(Frame(type, id, time, payload).encode())
            c.ratchet = r.serialize()
            s.outbox.add(OutItem(c.id, c.topicOut, Base64.encodeToString(env, Base64.NO_WRAP), msgId))
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun flushOutbox() {
        while (true) {
            val item: OutItem? = synchronized(lock) { store?.outbox?.firstOrNull() }
            if (item == null) return
            val code = Relay.publish(item.topic, Base64.decode(item.env, Base64.NO_WRAP))
            val accepted = code in 200..299
            val retryLater = code == 0 || code == 429 || code >= 500
            if (!accepted && retryLater) return
            synchronized(lock) {
                val s = store
                if (s != null) {
                    s.outbox.remove(item)
                    if (item.msgId != null) {
                        val m = s.findMsg(item.contactId, item.msgId)
                        if (m != null && m.state < 2) m.state = if (accepted) 1 else 3
                    }
                    saveQuiet(s)
                }
            }
            notifyUi()
        }
    }

    private fun handleIncoming(topic: String, ntfyId: String, timeSec: Long, b64: String) {
        var notify = false
        var needFlush = false
        synchronized(lock) {
            val s = store
            if (s != null && ntfyId.isNotEmpty() && s.markSeen(ntfyId)) {
                if (timeSec > s.lastTs) s.lastTs = timeSec
                val c = s.contacts.firstOrNull { it.topicIn == topic }
                if (c != null) {
                    val env: ByteArray? = try {
                        Base64.decode(b64.trim(), Base64.DEFAULT)
                    } catch (_: Exception) {
                        null
                    }
                    if (env != null && env.size == Ratchet.ENVELOPE_SIZE) {
                        try {
                            val r = ratchetFor(c)
                            val plain = r.decrypt(env)
                            c.ratchet = r.serialize()
                            val f = Frame.decode(plain)
                            if (f.type == Frame.TEXT) {
                                if (!c.blocked) {
                                    val idHex = Bytes.hex(f.id)
                                    val list = s.msgs(c.id)
                                    if (list.none { it.id == idHex && !it.outgoing }) {
                                        val now = System.currentTimeMillis()
                                        val t = if (f.time in 1..now) f.time else now
                                        list.add(Msg(idHex, false, t, String(f.payload, Charsets.UTF_8), 0))
                                        val watching = ToqueApp.visible && openChat == c.id
                                        if (!watching) c.unread++
                                        if (!ToqueApp.visible) notify = true
                                    }
                                    if (encryptLocked(s, c, Frame.ACK, f.id, nowMs(), ByteArray(0), null)) needFlush = true
                                }
                            } else if (f.type == Frame.ACK) {
                                val m = s.findMsg(c.id, Bytes.hex(f.id))
                                if (m != null && m.state < 2) m.state = 2
                            }
                        } catch (_: Exception) {
                            // mensagem invalida, repetida ou adulterada: ignorada (o estado nao muda)
                        }
                    }
                }
                saveQuiet(s)
            }
        }
        if (notify) {
            val a = app
            if (a != null) Notifier.newMessage(a)
        }
        notifyUi()
        if (needFlush) flushOutbox()
    }

    private fun nowMs(): Long = System.currentTimeMillis()
}
