package pt.toque.app

import android.util.Base64
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/**
 * Transporte das mensagens (Toque 3.0): servico publico e gratuito ntfy.sh por HTTPS.
 * So ve texto cifrado de tamanho fixo e nomes de topico aleatorios, mas VE O TEU IP
 * (ainda sem Tor; o Tor entra no Toque 4.0).
 */
object Relay {
    const val BASE = "https://ntfy.sh"

    @Volatile
    var status: String = "Parado"
        private set

    var onMessage: ((String, String, Long, String) -> Unit)? = null
    var onTick: (() -> Unit)? = null
    var onStatus: (() -> Unit)? = null

    @Volatile
    private var gen = 0

    @Volatile
    private var conn: HttpURLConnection? = null

    private fun setStatus(s: String) {
        if (status != s) {
            status = s
            onStatus?.invoke()
        }
    }

    /** Devolve o codigo HTTP (2xx = aceite) ou 0 se nao houve ligacao. */
    fun publish(topic: String, data: ByteArray): Int {
        var c: HttpURLConnection? = null
        return try {
            c = URL("$BASE/$topic").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 20000
            c.doOutput = true
            c.setRequestProperty("User-Agent", "Toque")
            c.setRequestProperty("Content-Type", "text/plain")
            val body = Base64.encodeToString(data, Base64.NO_WRAP).toByteArray(Charsets.UTF_8)
            c.outputStream.use { it.write(body) }
            c.responseCode
        } catch (e: Exception) {
            0
        } finally {
            try {
                c?.disconnect()
            } catch (_: Exception) {
            }
        }
    }

    @Synchronized
    fun start(topics: List<String>, since: Long) {
        stopInternal()
        if (topics.isEmpty()) {
            setStatus("Sem contactos")
            return
        }
        val myGen = ++gen
        val t = Thread { loop(myGen, topics, since) }
        t.isDaemon = true
        t.start()
    }

    @Synchronized
    fun stop() {
        stopInternal()
        setStatus("Parado")
    }

    private fun stopInternal() {
        gen++
        val c = conn
        conn = null
        try {
            c?.disconnect()
        } catch (_: Exception) {
        }
    }

    private fun loop(myGen: Int, topics: List<String>, initialSince: Long) {
        var since = initialSince
        var backoff = 2000L
        while (myGen == gen) {
            try {
                val sinceParam = if (since > 0) since.toString() else "12h"
                val url = URL("$BASE/${topics.joinToString(",")}/json?since=$sinceParam")
                val c = url.openConnection() as HttpURLConnection
                conn = c
                c.connectTimeout = 15000
                c.readTimeout = 120000
                c.setRequestProperty("User-Agent", "Toque")
                val code = c.responseCode
                if (code !in 200..299) throw java.io.IOException("HTTP $code")
                setStatus("Ligado ao servidor de entrega")
                backoff = 2000L
                val reader = BufferedReader(InputStreamReader(c.inputStream, Charsets.UTF_8))
                try {
                    while (myGen == gen) {
                        val line = reader.readLine() ?: break
                        if (line.isBlank()) continue
                        try {
                            val o = JSONObject(line)
                            when (o.optString("event")) {
                                "message" -> {
                                    val t = o.optLong("time", 0L)
                                    onMessage?.invoke(o.optString("topic"), o.optString("id"), t, o.optString("message"))
                                    if (t > since) since = t
                                }
                                "open", "keepalive" -> onTick?.invoke()
                            }
                        } catch (_: Exception) {
                        }
                    }
                } finally {
                    try {
                        reader.close()
                    } catch (_: Exception) {
                    }
                    try {
                        c.disconnect()
                    } catch (_: Exception) {
                    }
                }
            } catch (_: Exception) {
            }
            if (myGen != gen) break
            setStatus("Sem ligacao - a tentar de novo")
            var waited = 0L
            while (waited < backoff && myGen == gen) {
                try {
                    Thread.sleep(500)
                } catch (_: InterruptedException) {
                }
                waited += 500
            }
            backoff = minOf(backoff * 2, 60000L)
        }
    }
}
