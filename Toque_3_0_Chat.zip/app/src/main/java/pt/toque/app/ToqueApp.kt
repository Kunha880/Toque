package pt.toque.app

import android.app.Application

class ToqueApp : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            Engine.init(this)
        } catch (_: Exception) {
        }
    }

    companion object {
        /** true enquanto o ecra da app esta visivel. */
        @Volatile
        var visible: Boolean = false
    }
}
