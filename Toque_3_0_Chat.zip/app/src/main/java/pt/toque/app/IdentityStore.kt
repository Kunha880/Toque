package pt.toque.app

import android.content.Context
import android.util.Base64
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.spec.ECGenParameterSpec

object IdentityStore {
    private const val ALIAS = "toque_identity_v1"

    fun publicKey(context: Context): String {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (!ks.containsAlias(ALIAS)) {
            val generator = KeyPairGenerator.getInstance("EC", "AndroidKeyStore")
            generator.initialize(
                android.security.keystore.KeyGenParameterSpec.Builder(
                    ALIAS,
                    android.security.keystore.KeyProperties.PURPOSE_SIGN
                ).setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1"))
                 .setDigests(android.security.keystore.KeyProperties.DIGEST_SHA256)
                 .build()
            )
            generator.generateKeyPair()
        }
        val certificate = ks.getCertificate(ALIAS)
        return Base64.encodeToString(certificate.publicKey.encoded, Base64.NO_WRAP)
    }

    /** Apaga a chave de identidade 2.0 do Keystore (usado no apagamento total). */
    fun destroy() {
        try {
            val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            if (ks.containsAlias(ALIAS)) ks.deleteEntry(ALIAS)
        } catch (_: Exception) {
        }
    }
}
