package pt.toque.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.IsoDep
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import pt.toque.core.Frame
import pt.toque.core.Handshake
import pt.toque.core.SelfTest
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private enum class Screen { PIN, HOME, CHAT, INFO, ADD, CONFIRM, TOOLS, TEST, LEGACY }

    private lateinit var pinStore: PinStore
    private var unlocked = false
    private var nfc: NfcAdapter? = null
    private var readerEnabled = false
    private var statusView: TextView? = null
    private var screen = Screen.PIN
    private var notice: String? = null
    private var msgBox: LinearLayout? = null
    private var msgScroll: ScrollView? = null
    private var chatId: String? = null
    private val timeFmt = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())
    private val engineListener: () -> Unit = { onEngineChanged() }

    // ---------------------------------------------------------------- ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        pinStore = PinStore(this)
        nfc = NfcAdapter.getDefaultAdapter(this)
        try {
            Engine.init(this)
        } catch (_: Exception) {
        }
    }

    override fun onStart() {
        super.onStart()
        ToqueApp.visible = true
        Notifier.clear(this)
        Engine.addListener(engineListener)
        render()
    }

    override fun onPause() {
        disableReader()
        super.onPause()
    }

    override fun onStop() {
        ToqueApp.visible = false
        Engine.openChat = null
        Engine.removeListener(engineListener)
        disableReader()
        Pairing.responderActive = false
        Pairing.onResponderResult = null
        unlocked = false
        super.onStop()
    }

    private fun render() {
        when {
            !pinStore.hasPin() -> pinScreen(null)
            !unlocked -> pinScreen("")
            else -> {
                askNotificationPermissionOnce()
                home()
            }
        }
    }

    private fun askNotificationPermissionOnce() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            val sp = getSharedPreferences("toque_settings", Context.MODE_PRIVATE)
            if (!sp.getBoolean("asked_notif", false)) {
                sp.edit().putBoolean("asked_notif", true).apply()
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
            }
        }
    }

    private fun onEngineChanged() {
        if (!unlocked) return
        when (screen) {
            Screen.HOME -> home()
            Screen.CHAT -> refreshChat()
            else -> {
            }
        }
    }

    // ---------------------------------------------------------------- PIN

    private fun pinScreen(first: String?) {
        screen = Screen.PIN
        val field = EditText(this).apply {
            hint = "PIN (mínimo 6 números)"
            inputType = 0x00000012
            importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
        }
        val message = label(notice ?: "")
        notice = null
        if (first != null && first.isEmpty() && pinStore.triesLeft() < PinStore.MAX_TRIES) {
            message.text = "Tentativas restantes: ${pinStore.triesLeft()} de ${PinStore.MAX_TRIES}."
        }
        val button = Button(this).apply {
            text = if (first == null) "Criar PIN" else if (first.isEmpty()) "Desbloquear" else "Confirmar PIN"
            setOnClickListener {
                val value = field.text.toString()
                when {
                    first == null && value.length >= 6 -> pinScreen(value)
                    first == null -> message.text = "O PIN precisa de pelo menos 6 números."
                    first.isEmpty() -> {
                        when (pinStore.check(value)) {
                            PinResult.OK -> {
                                unlocked = true
                                render()
                            }
                            PinResult.WRONG -> {
                                field.setText("")
                                message.text = "PIN incorreto. Tentativas restantes: ${pinStore.triesLeft()} de " +
                                    "${PinStore.MAX_TRIES}. Ao falhar a 3.ª vez, todos os dados são apagados."
                            }
                            PinResult.WIPED -> {
                                pinStore = PinStore(this@MainActivity)
                                notice = "Três tentativas falhadas: todos os dados foram apagados."
                                pinScreen(null)
                            }
                        }
                    }
                    first == value -> {
                        pinStore.setPin(value)
                        unlocked = true
                        render()
                    }
                    else -> {
                        notice = "Os PINs não coincidem. Tenta de novo."
                        pinScreen(null)
                    }
                }
            }
        }
        val intro = when {
            first == null -> "Cria um PIN para proteger a aplicação.\n\nATENÇÃO: se falhares o PIN 3 vezes seguidas, " +
                "a app bloqueia e APAGA todos os dados (contactos, chaves e mensagens). Não há como recuperá-los."
            first.isEmpty() -> "Introduz o teu PIN."
            else -> "Repete o PIN."
        }
        show(label("TOQUE", 28f, true), label(intro), field, message, button)
    }

    // ---------------------------------------------------------------- inicio / conversas

    private fun home() {
        screen = Screen.HOME
        chatId = null
        Engine.openChat = null
        val views = ArrayList<View>()
        views.add(label("TOQUE 3.0", 26f, true))
        var line = "Transporte: ntfy.sh directo (sem Tor ainda)\nEstado: " + Engine.relayStatus()
        val err = Engine.loadError
        if (err != null) line += "\nAviso: não foi possível ler os dados guardados ($err)."
        views.add(label(line, 12f))

        val contacts = Engine.contacts()
        if (contacts.isEmpty()) {
            views.add(label("Ainda não tens conversas. Toca em «Adicionar contacto» e encosta o teu telemóvel ao de outra pessoa."))
        } else {
            for (c in contacts) views.add(contactRow(c))
        }
        views.add(Button(this).apply {
            text = "Adicionar contacto (NFC)"
            setOnClickListener { addContact() }
        })
        views.add(Button(this).apply {
            text = "Ferramentas e diagnóstico"
            setOnClickListener { tools() }
        })
        views.add(Button(this).apply {
            text = "Bloquear"
            setOnClickListener {
                unlocked = false
                render()
            }
        })
        show(*views.toTypedArray())
    }

    private fun contactRow(c: ContactView): View {
        return Button(this).apply {
            setAllCaps(false)
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
            val unread = if (c.unread > 0) "   (" + c.unread + (if (c.unread > 1) " novas)" else " nova)") else ""
            val last = c.lastText?.let { if (it.length > 40) it.take(40) + "…" else it } ?: "Sem mensagens"
            text = c.alias + (if (c.blocked) " [bloqueado]" else "") + unread + "\n" + last
            setOnClickListener { chat(c.id) }
        }
    }

    // ---------------------------------------------------------------- conversa

    private fun chat(id: String) {
        val c = Engine.contact(id)
        if (c == null) {
            home()
            return
        }
        screen = Screen.CHAT
        chatId = id
        Engine.openChat = id
        Engine.markRead(id)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(4))
        }
        top.addView(Button(this).apply {
            text = "←"
            setOnClickListener { home() }
        })
        top.addView(TextView(this).apply {
            text = c.alias
            textSize = 20f
            setTypeface(null, Typeface.BOLD)
            setPadding(dp(8), 0, dp(8), 0)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(Button(this).apply {
            text = "ℹ"
            setOnClickListener { contactInfo(id) }
        })
        root.addView(top)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val scroll = ScrollView(this)
        scroll.addView(box)
        msgBox = box
        msgScroll = scroll
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(8))
        }
        val input = EditText(this).apply {
            hint = "Mensagem"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            maxLines = 4
            imeOptions = EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING
            importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
        }
        bar.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(Button(this).apply {
            text = "Enviar"
            setOnClickListener {
                val text = input.text.toString().trim()
                if (text.isEmpty()) return@setOnClickListener
                if (text.toByteArray(Charsets.UTF_8).size > Frame.MAX_PAYLOAD) {
                    Toast.makeText(
                        this@MainActivity,
                        "Mensagem demasiado longa (máximo " + Frame.MAX_PAYLOAD + " bytes).",
                        Toast.LENGTH_LONG
                    ).show()
                    return@setOnClickListener
                }
                Engine.send(id, text)
                input.setText("")
            }
        })
        root.addView(bar)

        setContentView(root)
        applyInsets(root)
        refreshChat()
    }

    private fun refreshChat() {
        val id = chatId ?: return
        val box = msgBox ?: return
        box.removeAllViews()
        val list = Engine.messages(id)
        if (list.isEmpty()) {
            box.addView(label("Ainda sem mensagens. Escreve a primeira.", 14f))
        }
        for (m in list) box.addView(bubble(m))
        val sv = msgScroll
        sv?.post { sv.fullScroll(View.FOCUS_DOWN) }
    }

    private fun bubble(m: MsgView): View {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = if (m.outgoing) Gravity.END else Gravity.START
        }
        val tv = TextView(this).apply {
            text = m.text
            textSize = 16f
            setTextColor(Color.BLACK)
            maxWidth = dp(290)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            val bg = GradientDrawable()
            bg.cornerRadius = dp(14).toFloat()
            bg.setColor(Color.parseColor(if (m.outgoing) "#CFE6FF" else "#E6E6E6"))
            background = bg
        }
        val state = if (!m.outgoing) "" else when (m.state) {
            0 -> " · A enviar…"
            1 -> " · Enviada"
            2 -> " · Entregue"
            else -> " · Falhou"
        }
        val meta = TextView(this).apply {
            text = timeFmt.format(Date(m.time)) + state
            textSize = 11f
            setTextColor(Color.GRAY)
        }
        wrap.addView(tv)
        wrap.addView(meta)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, dp(4), 0, dp(4))
        wrap.layoutParams = lp
        return wrap
    }

    private fun contactInfo(id: String) {
        val c = Engine.contact(id)
        if (c == null) {
            home()
            return
        }
        screen = Screen.INFO
        val alias = EditText(this).apply {
            setText(c.alias)
            hint = "Alcunha"
        }
        val msg = label("")
        val views = ArrayList<View>()
        views.add(label("CONTACTO", 24f, true))
        views.add(label("A alcunha só existe neste telemóvel. A outra pessoa pode ter-te guardado com outro nome."))
        views.add(alias)
        views.add(Button(this).apply {
            text = "Guardar alcunha"
            setOnClickListener {
                val a = alias.text.toString().trim()
                if (a.isEmpty()) {
                    msg.text = "A alcunha não pode ficar vazia."
                } else {
                    Engine.rename(id, a)
                    chat(id)
                }
            }
        })
        views.add(msg)
        views.add(label("Impressão digital da conversa (tem de ser igual nos dois telemóveis):", 13f))
        views.add(label(c.fingerprint.chunked(4).joinToString(" "), 13f))
        views.add(Button(this).apply {
            text = if (c.blocked) "Desbloquear contacto" else "Bloquear contacto"
            setOnClickListener {
                Engine.setBlocked(id, !c.blocked)
                chat(id)
            }
        })
        views.add(Button(this).apply {
            text = "Apagar contacto e conversa"
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Apagar contacto?")
                    .setMessage("Apaga a chave desta conversa e todas as mensagens neste telemóvel. Para voltar a falar é preciso encostar os telemóveis outra vez.")
                    .setPositiveButton("Apagar") { _, _ ->
                        Engine.remove(id)
                        home()
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
        })
        views.add(Button(this).apply {
            text = "Voltar"
            setOnClickListener { chat(id) }
        })
        show(*views.toTypedArray())
    }

    // ---------------------------------------------------------------- adicionar contacto (NFC)

    private fun addContact() {
        screen = Screen.ADD
        disableReader()
        Pairing.responderActive = false
        Pairing.onResponderResult = null
        val status = label("Escolhe o teu papel. Os dois telemóveis devem ter o ecrã ligado e desbloqueado, com o NFC ativo.")
        statusView = status
        show(
            label("ADICIONAR CONTACTO", 24f, true),
            label("Um telemóvel toca em «Eu leio» e o outro em «Eu sou lido». Depois encostem as costas dos telemóveis. Funciona nos dois sentidos de uma só vez."),
            Button(this).apply {
                text = "Eu leio"
                setOnClickListener { startPairRead() }
            },
            Button(this).apply {
                text = "Eu sou lido"
                setOnClickListener { startPairRespond() }
            },
            status,
            Button(this).apply {
                text = "Cancelar"
                setOnClickListener {
                    disableReader()
                    Pairing.responderActive = false
                    Pairing.onResponderResult = null
                    home()
                }
            }
        )
    }

    private fun nfcReady(): Boolean {
        val a = nfc
        if (a == null) {
            statusView?.text = "Este telemóvel não tem NFC."
            return false
        }
        if (!a.isEnabled) {
            statusView?.text = "Ativa o NFC nas definições do Android."
            return false
        }
        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_NFC_HOST_CARD_EMULATION)) {
            statusView?.text = "Este telemóvel não suporta emulação de cartão (HCE)."
            return false
        }
        return true
    }

    private fun startPairRead() {
        if (!nfcReady()) return
        Pairing.responderActive = false
        Pairing.onResponderResult = null
        enableReader { tag -> pairRead(tag) }
        statusView?.text = "A ler… encosta ao outro telemóvel (que deve estar em «Eu sou lido»)."
    }

    private fun pairRead(tag: Tag) {
        try {
            val res = Pairing.runReader(tag)
            runOnUiThread {
                disableReader()
                confirmPair(res)
            }
        } catch (e: Exception) {
            runOnUiThread {
                statusView?.text = "Falhou: " + (e.message ?: "erro desconhecido") + " Tenta de novo."
            }
        }
    }

    private fun startPairRespond() {
        if (!nfcReady()) return
        disableReader()
        Pairing.onResponderResult = { res -> confirmPair(res) }
        Pairing.responderActive = true
        statusView?.text = "Pronto. Mantém este ecrã aberto; o outro telemóvel vai ler o teu."
    }

    private fun confirmPair(res: Handshake.Result) {
        screen = Screen.CONFIRM
        disableReader()
        Pairing.responderActive = false
        Pairing.onResponderResult = null
        val alias = EditText(this).apply { hint = "Alcunha para este contacto" }
        val msg = label("")
        show(
            label("CONFIRMAR", 24f, true),
            label("Compara este código com o do outro telemóvel. Têm de ser exatamente iguais."),
            label(res.code, 40f, true),
            label("Se for diferente, toca em «Não é igual»: alguém pode estar a interferir na ligação."),
            alias,
            msg,
            Button(this).apply {
                text = "É igual — guardar contacto"
                setOnClickListener {
                    val a = alias.text.toString().trim()
                    if (a.isEmpty()) {
                        msg.text = "Escolhe uma alcunha."
                        return@setOnClickListener
                    }
                    isEnabled = false
                    Engine.addContact(res, a) { saved ->
                        if (saved) {
                            Toast.makeText(this@MainActivity, "Contacto guardado.", Toast.LENGTH_SHORT).show()
                            home()
                        } else {
                            msg.text = "Não foi possível guardar (já existe?)."
                            isEnabled = true
                        }
                    }
                }
            },
            Button(this).apply {
                text = "Não é igual — cancelar"
                setOnClickListener { home() }
            }
        )
    }

    // ---------------------------------------------------------------- ferramentas

    private fun tools() {
        screen = Screen.TOOLS
        show(
            label("FERRAMENTAS", 24f, true),
            label(
                "Toque 3.0 (teste)\n" +
                    "Encriptação: X25519 + Double Ratchet + AES-256-GCM (implementação própria da especificação; não auditada).\n" +
                    "Transporte: ntfy.sh directo. O servidor vê o teu IP e mensagens cifradas de tamanho fixo. Tor: Toque 4.0.\n" +
                    "Dados: ficheiro cifrado com chave do Android Keystore, fora das cópias de segurança.",
                13f
            ),
            Button(this).apply {
                text = "Autoteste da criptografia"
                setOnClickListener { selfTest() }
            },
            Button(this).apply {
                text = "Diagnóstico NFC 2.0 (contacto simples)"
                setOnClickListener { legacy() }
            },
            Button(this).apply {
                text = "Alterar PIN"
                setOnClickListener { pinScreen(null) }
            },
            Button(this).apply {
                text = "Apagar todos os dados agora"
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Apagar tudo?")
                        .setMessage("Apaga contactos, chaves e mensagens deste telemóvel. Não há como recuperar.")
                        .setPositiveButton("Apagar tudo") { _, _ ->
                            getSharedPreferences("lock", Context.MODE_PRIVATE).edit().clear().commit()
                            Wipe.everything(this@MainActivity)
                            pinStore = PinStore(this@MainActivity)
                            unlocked = false
                            notice = "Todos os dados foram apagados."
                            pinScreen(null)
                        }
                        .setNegativeButton("Cancelar", null)
                        .show()
                }
            },
            Button(this).apply {
                text = "Voltar"
                setOnClickListener { home() }
            }
        )
    }

    private fun selfTest() {
        screen = Screen.TEST
        val out = label("A correr o autoteste…", 12f)
        show(
            label("AUTOTESTE", 24f, true),
            out,
            Button(this).apply {
                text = "Voltar"
                setOnClickListener { tools() }
            }
        )
        Thread {
            val r = try {
                SelfTest.run()
            } catch (e: Throwable) {
                "AUTOTESTE FALHOU: " + (e.message ?: e.javaClass.simpleName)
            }
            runOnUiThread { out.text = r }
        }.start()
    }

    // ---------------------------------------------------------------- diagnostico NFC 2.0 (inalterado)

    private fun legacy() {
        screen = Screen.LEGACY
        val adapter = nfc
        val supportsNfc = adapter != null
        val supportsHce = packageManager.hasSystemFeature(PackageManager.FEATURE_NFC_HOST_CARD_EMULATION)
        val status = label(
            "NFC: " + when {
                !supportsNfc -> "não disponível"
                !adapter!!.isEnabled -> "desligado — ativa-o nas definições"
                else -> "ligado"
            } + "\nHCE: " + if (supportsHce) "disponível" else "não disponível neste equipamento"
        )
        statusView = label("Escolhe uma operação. (Contactos 2.0 não têm mensagens.)")
        val share = Button(this).apply {
            text = "Apresentar o meu contacto por NFC"
            setOnClickListener {
                if (adapter == null || !adapter.isEnabled || !supportsHce) {
                    statusView?.text = "Este equipamento precisa de NFC ligado e suporte HCE."
                } else {
                    disableReader()
                    statusView?.text = "Pronto para partilhar. Mantém este ecrã aberto e aproxima o outro telemóvel em modo «Ler contacto»."
                }
            }
        }
        val read = Button(this).apply {
            text = "Ler contacto por NFC"
            setOnClickListener {
                if (adapter == null || !adapter.isEnabled) {
                    statusView?.text = "Ativa o NFC nas definições do Android."
                } else {
                    enableReader { tag -> readContactLegacy(tag) }
                    statusView?.text = "Modo de leitura ativo. Encosta à parte traseira do telemóvel que está a apresentar o contacto."
                }
            }
        }
        val list = Button(this).apply {
            text = "Contactos 2.0"
            setOnClickListener { showLegacyContacts() }
        }
        val back = Button(this).apply {
            text = "Voltar"
            setOnClickListener {
                disableReader()
                tools()
            }
        }
        show(label("DIAGNÓSTICO NFC 2.0", 24f, true), status, share, read, list, statusView!!, back)
    }

    private fun readContactLegacy(tag: Tag) {
        var result: String? = null
        try {
            val iso = IsoDep.get(tag) ?: throw IllegalStateException("O equipamento não disponibilizou ISO-DEP.")
            iso.connect()
            iso.timeout = 5000
            val aid = byteArrayOf(
                0x00, 0xA4.toByte(), 0x04, 0x00, 0x07,
                0xF0.toByte(), 0x41, 0x50, 0x51, 0x55, 0x45, 0x01
            )
            val selected = iso.transceive(aid)
            if (selected.size < 2 || selected[selected.size - 2] != 0x90.toByte()) {
                throw IllegalStateException("O serviço Toque não foi encontrado.")
            }
            val response = iso.transceive(byteArrayOf(0x80.toByte(), 0xCA.toByte(), 0x00, 0x00, 0x00))
            iso.close()
            if (response.size < 3 || response[response.size - 2] != 0x90.toByte()) {
                throw IllegalStateException("Não foi possível receber o contacto.")
            }
            result = String(response, 0, response.size - 2, Charsets.UTF_8)
        } catch (e: Exception) {
            runOnUiThread { statusView?.text = "Falha NFC: ${e.message ?: "erro desconhecido"}" }
        }
        if (result != null) {
            val value = result!!
            runOnUiThread { askAliasAndSaveLegacy(value) }
        }
    }

    private fun askAliasAndSaveLegacy(payload: String) {
        disableReader()
        if (!payload.startsWith("TOQUE1:")) {
            statusView?.text = "Formato de contacto desconhecido."
            return
        }
        val key = payload.removePrefix("TOQUE1:")
        try {
            Base64.decode(key, Base64.DEFAULT)
        } catch (_: Exception) {
            statusView?.text = "Chave pública inválida."
            return
        }
        val input = EditText(this).apply { hint = "Alcunha para este contacto" }
        AlertDialog.Builder(this)
            .setTitle("Guardar contacto")
            .setMessage("A alcunha só é guardada neste telemóvel.")
            .setView(input)
            .setPositiveButton("Guardar") { _, _ ->
                val alias = input.text.toString().trim()
                if (alias.isBlank()) {
                    statusView?.text = "Escolhe uma alcunha para guardar o contacto."
                } else {
                    val arr = JSONArray(legacyPrefs().getString("contacts", "[]"))
                    val fingerprint = MessageDigest.getInstance("SHA-256").digest(Base64.decode(key, Base64.DEFAULT))
                        .joinToString("") { "%02X".format(it) }
                    if ((0 until arr.length()).any { arr.getJSONObject(it).optString("fingerprint") == fingerprint }) {
                        statusView?.text = "Este contacto já está guardado."
                    } else {
                        arr.put(JSONObject().put("alias", alias).put("publicKey", key).put("fingerprint", fingerprint))
                        legacyPrefs().edit().putString("contacts", arr.toString()).apply()
                        statusView?.text = "Contacto «$alias» guardado. Impressão digital: ${fingerprint.take(16)}…"
                    }
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showLegacyContacts() {
        val arr = JSONArray(legacyPrefs().getString("contacts", "[]"))
        val lines = (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            "• ${o.optString("alias")}\n  Chave: ${o.optString("fingerprint").take(24)}…"
        }
        show(
            label("CONTACTOS 2.0", 24f, true),
            label(if (lines.isEmpty()) "Ainda não tens contactos 2.0." else lines.joinToString("\n\n")),
            Button(this).apply {
                text = "Voltar"
                setOnClickListener { legacy() }
            }
        )
    }

    private fun legacyPrefs() = getSharedPreferences("toque_contacts", Context.MODE_PRIVATE)

    // ---------------------------------------------------------------- NFC (leitor)

    private fun enableReader(cb: (Tag) -> Unit) {
        val a = nfc ?: return
        readerEnabled = true
        a.enableReaderMode(
            this, { tag -> cb(tag) },
            NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_NFC_B or NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK,
            Bundle()
        )
    }

    private fun disableReader() {
        if (readerEnabled) {
            try {
                nfc?.disableReaderMode(this)
            } catch (_: Exception) {
            }
            readerEnabled = false
        }
    }

    // ---------------------------------------------------------------- ajudas de interface

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    private fun applyInsets(v: View) {
        v.setOnApplyWindowInsetsListener { view, insets ->
            val l: Int
            val t: Int
            val r: Int
            val b: Int
            if (Build.VERSION.SDK_INT >= 30) {
                val i = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
                l = i.left
                t = i.top
                r = i.right
                b = i.bottom
            } else {
                l = insets.systemWindowInsetLeft
                t = insets.systemWindowInsetTop
                r = insets.systemWindowInsetRight
                b = insets.systemWindowInsetBottom
            }
            view.setPadding(l, t, r, b)
            insets
        }
        v.requestApplyInsets()
    }

    private fun show(vararg views: View) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
        }
        views.forEach { box.addView(it) }
        val sv = ScrollView(this)
        sv.addView(box)
        setContentView(sv)
        applyInsets(sv)
    }

    private fun label(text: String, size: Float = 16f, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = size
        if (bold) setTypeface(null, Typeface.BOLD)
        setPadding(0, dp(8), 0, dp(8))
    }
}
