package pt.toque.app

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

class Contact(
    val id: String,
    var alias: String,
    val fingerprint: String,
    val topicOut: String,
    val topicIn: String,
    val created: Long,
    var blocked: Boolean,
    var unread: Int,
    var ratchet: ByteArray
)

/** state (saida): 0 a enviar, 1 enviada, 2 entregue, 3 falhou. Entrada: 0. */
class Msg(
    val id: String,
    val outgoing: Boolean,
    val time: Long,
    val text: String,
    var state: Int
)

/** Envelope ja cifrado a espera de ser publicado. msgId so existe para mensagens de texto. */
class OutItem(
    val contactId: String,
    val topic: String,
    val env: String,
    val msgId: String?
)

/**
 * Armazenamento local: um unico ficheiro cifrado com AES-256-GCM (chave no Keystore),
 * fora das copias de seguranca do Android. Guarda contactos, estado do Double Ratchet,
 * historico de mensagens e a fila de envio.
 */
class Store(private val ctx: Context) {
    val contacts = ArrayList<Contact>()
    val messages = HashMap<String, ArrayList<Msg>>()
    val outbox = ArrayList<OutItem>()
    private val seen = LinkedHashSet<String>()
    var lastTs = 0L

    fun contact(id: String): Contact? = contacts.firstOrNull { it.id == id }

    fun msgs(contactId: String): ArrayList<Msg> = messages.getOrPut(contactId) { ArrayList() }

    fun findMsg(contactId: String, msgId: String): Msg? =
        messages[contactId]?.firstOrNull { it.id == msgId && it.outgoing }

    /** Devolve false se ja tinha sido processada. */
    fun markSeen(id: String): Boolean {
        if (!seen.add(id)) return false
        while (seen.size > 2000) {
            val it = seen.iterator()
            it.next()
            it.remove()
        }
        return true
    }

    fun save() {
        val j = JSONObject()
        j.put("v", 1)
        j.put("lastTs", lastTs)
        val cs = JSONArray()
        for (c in contacts) {
            cs.put(
                JSONObject()
                    .put("id", c.id).put("alias", c.alias).put("fp", c.fingerprint)
                    .put("out", c.topicOut).put("in", c.topicIn).put("created", c.created)
                    .put("blocked", c.blocked).put("unread", c.unread)
                    .put("ratchet", Base64.encodeToString(c.ratchet, Base64.NO_WRAP))
            )
        }
        j.put("contacts", cs)
        val ms = JSONObject()
        for ((cid, list) in messages) {
            val arr = JSONArray()
            for (m in list) {
                arr.put(
                    JSONObject().put("id", m.id).put("o", m.outgoing).put("t", m.time)
                        .put("x", m.text).put("s", m.state)
                )
            }
            ms.put(cid, arr)
        }
        j.put("messages", ms)
        val ob = JSONArray()
        for (o in outbox) {
            val jo = JSONObject().put("c", o.contactId).put("t", o.topic).put("e", o.env)
            if (o.msgId != null) jo.put("m", o.msgId)
            ob.put(jo)
        }
        j.put("outbox", ob)
        val sv = JSONArray()
        for (s in seen) sv.put(s)
        j.put("seen", sv)

        val sealed = Vault.seal(j.toString().toByteArray(Charsets.UTF_8))
        val dir = ctx.noBackupFilesDir
        val tmp = File(dir, FILE + ".tmp")
        val dst = File(dir, FILE)
        FileOutputStream(tmp).use { out ->
            out.write(sealed)
            out.fd.sync()
        }
        if (!tmp.renameTo(dst)) {
            dst.delete()
            tmp.renameTo(dst)
        }
    }

    companion object {
        private const val FILE = "toque.dat"

        fun load(ctx: Context): Store {
            val s = Store(ctx)
            val f = File(ctx.noBackupFilesDir, FILE)
            if (!f.exists()) return s
            val j = JSONObject(String(Vault.open(f.readBytes()), Charsets.UTF_8))
            s.lastTs = j.optLong("lastTs", 0L)
            val cs = j.optJSONArray("contacts") ?: JSONArray()
            for (i in 0 until cs.length()) {
                val o = cs.getJSONObject(i)
                s.contacts.add(
                    Contact(
                        o.getString("id"), o.getString("alias"), o.getString("fp"),
                        o.getString("out"), o.getString("in"), o.getLong("created"),
                        o.optBoolean("blocked", false), o.optInt("unread", 0),
                        Base64.decode(o.getString("ratchet"), Base64.NO_WRAP)
                    )
                )
            }
            val ms = j.optJSONObject("messages")
            if (ms != null) {
                val keys = ms.keys()
                while (keys.hasNext()) {
                    val cid = keys.next()
                    val arr = ms.getJSONArray(cid)
                    val list = ArrayList<Msg>()
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        list.add(
                            Msg(o.getString("id"), o.getBoolean("o"), o.getLong("t"), o.getString("x"), o.getInt("s"))
                        )
                    }
                    s.messages[cid] = list
                }
            }
            val ob = j.optJSONArray("outbox") ?: JSONArray()
            for (i in 0 until ob.length()) {
                val o = ob.getJSONObject(i)
                s.outbox.add(
                    OutItem(o.getString("c"), o.getString("t"), o.getString("e"),
                        if (o.has("m")) o.getString("m") else null)
                )
            }
            val sv = j.optJSONArray("seen") ?: JSONArray()
            for (i in 0 until sv.length()) s.seen.add(sv.getString(i))
            return s
        }
    }
}
