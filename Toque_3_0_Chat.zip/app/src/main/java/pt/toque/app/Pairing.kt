package pt.toque.app

import android.nfc.Tag
import android.nfc.tech.IsoDep
import android.os.Handler
import android.os.Looper
import pt.toque.core.Handshake

/**
 * Emparelhamento Toque 3 por NFC, no mesmo servico (mesmo AID) que ja funcionava no 2.0.
 * Comando novo:  80 30 00 00 Lc <mensagem 1> 00   ->   <mensagem 2> 90 00
 * Os comandos do 2.0 (SELECT e 80 CA) nao foram alterados.
 */
object Pairing {
    private val AID = byteArrayOf(0xF0.toByte(), 0x41, 0x50, 0x51, 0x55, 0x45, 0x01)
    private val SW_OK = byteArrayOf(0x90.toByte(), 0x00)
    private val SW_NOT_ACTIVE = byteArrayOf(0x69.toByte(), 0x85.toByte())
    private val SW_WRONG_LENGTH = byteArrayOf(0x67.toByte(), 0x00)
    private val SW_WRONG_DATA = byteArrayOf(0x6A.toByte(), 0x80.toByte())

    private val main = Handler(Looper.getMainLooper())

    /** So responde ao emparelhamento quando o utilizador tocou em "Ser lido". */
    @Volatile
    var responderActive: Boolean = false

    /** Chamado na thread principal quando o telemovel lido terminou o emparelhamento. */
    @Volatile
    var onResponderResult: ((Handshake.Result) -> Unit)? = null

    // ---------- lado que e lido (chamado pelo servico HCE) ----------

    fun handleCommand(cmd: ByteArray): ByteArray {
        if (!responderActive) return SW_NOT_ACTIVE
        if (cmd.size < 5) return SW_WRONG_LENGTH
        val lc = cmd[4].toInt() and 0xff
        if (cmd.size < 5 + lc) return SW_WRONG_LENGTH
        val msg1 = cmd.copyOfRange(5, 5 + lc)
        return try {
            val r = Handshake.respond(msg1)
            val cb = onResponderResult
            main.post { cb?.invoke(r.result) }
            r.message2 + SW_OK
        } catch (_: Exception) {
            SW_WRONG_DATA
        }
    }

    // ---------- lado que le (chamado na thread do leitor NFC) ----------

    fun runReader(tag: Tag): Handshake.Result {
        val iso = IsoDep.get(tag) ?: throw IllegalStateException("O telemovel nao disponibilizou ISO-DEP.")
        iso.connect()
        try {
            iso.timeout = 5000
            val select = byteArrayOf(0x00, 0xA4.toByte(), 0x04, 0x00, AID.size.toByte()) + AID
            val r1 = iso.transceive(select)
            if (!isOk(r1)) throw IllegalStateException("O servico Toque nao foi encontrado no outro telemovel.")

            val ini = Handshake.Initiator()
            val m1 = ini.message1()
            val cmd = byteArrayOf(0x80.toByte(), 0x30, 0x00, 0x00, m1.size.toByte()) + m1 + byteArrayOf(0x00)
            val r2 = iso.transceive(cmd)
            if (r2.size == 2 && r2[0] == 0x69.toByte()) {
                throw IllegalStateException("O outro telemovel nao esta em modo Ser lido.")
            }
            if (!isOk(r2) || r2.size != Handshake.MSG2_SIZE + 2) {
                throw IllegalStateException("Resposta invalida do outro telemovel.")
            }
            return ini.finish(r2.copyOfRange(0, r2.size - 2))
        } finally {
            try {
                iso.close()
            } catch (_: Exception) {
            }
        }
    }

    private fun isOk(r: ByteArray): Boolean =
        r.size >= 2 && r[r.size - 2] == 0x90.toByte() && r[r.size - 1] == 0x00.toByte()
}
