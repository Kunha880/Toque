package pt.toque.app

import android.app.NotificationManager
import android.content.Context
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

enum class PinResult { OK, WRONG, WIPED }

/** Guarda so um hash do PIN (PBKDF2-HMAC-SHA256 + sal aleatorio), nunca o PIN. */
class PinStore(private val ctx: Context) {
    private val p = ctx.getSharedPreferences("lock", Context.MODE_PRIVATE)

    fun hasPin(): Boolean = p.contains("hash")

    fun setPin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        p.edit()
            .putString("salt", toHex(salt))
            .putString("hash", toHex(derive(pin, salt)))
            .putInt("fails", 0)
            .commit()
    }

    fun triesLeft(): Int = MAX_TRIES - p.getInt("fails", 0)

    /**
     * O contador sobe e e gravado ANTES de verificar o PIN: fechar a app a meio nao
     * devolve tentativas. Ao atingir MAX_TRIES apaga todos os dados.
     */
    fun check(pin: String): PinResult {
        val salt = fromHex(p.getString("salt", "") ?: "")
        val expected = fromHex(p.getString("hash", "") ?: "")
        val fails = p.getInt("fails", 0) + 1
        p.edit().putInt("fails", fails).commit()
        val ok = MessageDigest.isEqual(derive(pin, salt), expected)
        if (ok) {
            p.edit().putInt("fails", 0).commit()
            return PinResult.OK
        }
        if (fails >= MAX_TRIES) {
            p.edit().clear().commit()
            Wipe.everything(ctx)
            return PinResult.WIPED
        }
        return PinResult.WRONG
    }

    private fun derive(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 150_000, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    private fun toHex(b: ByteArray): String = b.joinToString("") { "%02x".format(it) }

    private fun fromHex(s: String): ByteArray =
        s.chunked(2).map { it.toInt(16).toByte() }.toByteArray()

    companion object {
        const val MAX_TRIES = 3
    }
}

/** Apagamento total: chaves do Keystore, ficheiros, preferencias e notificacoes. */
object Wipe {
    fun everything(ctx: Context) {
        try {
            Engine.reset()
        } catch (_: Exception) {
        }
        try {
            Relay.stop()
        } catch (_: Exception) {
        }
        // Apagar a chave torna ilegivel tudo o que foi cifrado com ela
        Vault.destroy()
        IdentityStore.destroy()
        val dirs = listOf(ctx.filesDir, ctx.noBackupFilesDir, ctx.cacheDir)
        for (d in dirs) {
            try {
                d.listFiles()?.forEach { it.deleteRecursively() }
            } catch (_: Exception) {
            }
        }
        for (name in listOf("lock", "toque_contacts", "toque_settings")) {
            try {
                ctx.deleteSharedPreferences(name)
            } catch (_: Exception) {
            }
        }
        try {
            ctx.getSystemService(NotificationManager::class.java)?.cancelAll()
        } catch (_: Exception) {
        }
    }
}
