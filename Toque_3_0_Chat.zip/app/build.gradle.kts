plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "pt.toque.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "pt.toque.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "3.0-chat"
    }
    // Chave de assinatura FIXA de teste (app/debug.keystore): permite instalar versoes
    // novas por cima das anteriores sem desinstalar. Nao usar para publicar a app.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    packaging {
        resources {
            excludes += setOf("META-INF/versions/9/OSGI-INF/MANIFEST.MF", "META-INF/DEPENDENCIES")
        }
    }
}
dependencies {
    // X25519 (RFC 7748). Resto da criptografia usa as classes do proprio Android (JCA).
    implementation("org.bouncycastle:bcprov-jdk18on:1.78.1")
}
